/* Сальдо — логика страницы */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const NBSP = ' ';
const nf = new Intl.NumberFormat('ru-RU', {maximumFractionDigits: 0});
const rub = n => nf.format(Math.round(n)) + NBSP + '₽';
const signed = n => (n > 0 ? '+' : n < 0 ? '−' : '') + nf.format(Math.abs(Math.round(n))) + NBSP + '₽';
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c; };
const MONTHS_G = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
const MONTHS_N = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const MONTHS_S = ['янв','фев','мар','апр','май','июн','июл','авг','сен','окт','ноя','дек'];
const WD = ['вс','пн','вт','ср','чт','пт','сб'];
const dLong = d => `${d.getDate()} ${MONTHS_G[d.getMonth()]}`;
const compact = n => {
  const a = Math.abs(n), s = n < 0 ? '−' : '';
  if (a >= 1e6) return s + (a / 1e6).toLocaleString('ru-RU', {maximumFractionDigits: 1}) + ' млн';
  if (a >= 1e3) return s + Math.round(a / 1e3) + ' тыс';
  return s + a;
};

/* ---------- шапка и меню ---------- */
const header = $('#header');
addEventListener('scroll', () => header.classList.toggle('scrolled', scrollY > 8), {passive: true});
const burger = $('#burger');
const setNav = open => {
  document.body.classList.toggle('nav-open', open);
  burger.setAttribute('aria-expanded', open);
  burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
};
burger.addEventListener('click', () => setNav(!document.body.classList.contains('nav-open')));
$$('#mobileNav a').forEach(a => a.addEventListener('click', () => setNav(false)));
addEventListener('keydown', e => { if (e.key === 'Escape') setNav(false); });

/* ---------- модель денег ---------- */
// Детерминированный генератор: цифры одинаковые при каждом открытии
const rng = (seed => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; })(7);
const today = new Date(); today.setHours(0, 0, 0, 0);
const PAST = 30, FUTURE = 90;
const days = [];
for (let i = -PAST; i <= FUTURE; i++) {
  const d = new Date(today); d.setDate(d.getDate() + i);
  const dow = d.getDay(), dom = d.getDate(), ev = [];
  const weekend = dow === 0 || dow === 6;
  ev.push({n: 'Выручка по эквайрингу', a: Math.round((weekend ? 152000 : 118000) * (.86 + rng() * .28) / 100) * 100, daily: true});
  if (dow === 1 || dow === 3 || dow === 5) ev.push({n: 'Закупка у поставщиков', a: -Math.round((118000 + rng() * 30000) / 100) * 100, daily: true});
  if (dom === 5) ev.push({n: 'Аренда трёх кофеен', a: -380000});
  if (dom === 10) ev.push({n: 'Аванс сотрудникам', a: -560000});
  if (dom === 15) ev.push({n: 'Коммунальные услуги', a: -85000});
  if (dom === 18) ev.push({n: 'Лизинг кофемашин', a: -64000});
  if (dom === 25) ev.push({n: 'Зарплата сотрудникам', a: -720000});
  if (dom === 28) ev.push({n: 'Страховые взносы', a: -190000});
  if (i === 22) ev.push({n: 'Обжарщику за квартал', a: -1150000});
  if (i === 16 || i === 47) ev.push({n: 'Кейтеринг для ООО «Бриз»', a: 240000, inflow: true});
  if (i === 63) ev.push({n: 'Возврат депозита', a: 300000, inflow: true});
  days.push({i, d, ev, net: ev.reduce((s, e) => s + e.a, 0)});
}
// Остаток подбираем так, чтобы в горизонте 60 дней был один понятный разрыв
{
  let b = 0;
  days.forEach(x => { b += x.net; x.raw = b; });
  const t0 = days.find(x => x.i === 0).raw;
  const minFut = Math.min(...days.filter(x => x.i > 0 && x.i <= 60).map(x => x.raw));
  const shift = -147300 - minFut; // минимум в прогнозе: −147 300 ₽
  days.forEach(x => { x.b = x.raw + shift; });
  const now = t0 + shift;
  const accs = $$('.acc em[data-share]');
  let rest = now;
  accs.forEach((el, k) => {
    const v = k === accs.length - 1 ? rest : Math.round(now * +el.dataset.share / 1e4) * 100;
    rest -= v; el.textContent = rub(v);
  });
}
const byIndex = i => days[i + PAST];
const bigEvents = x => x.ev.filter(e => !e.daily);

/* ---------- дашборд ---------- */
let horizon = 60, drawn = false;
const svg = $('#chart'), tip = $('#tip'), wrap = $('#chartWrap');
const NS = 'http://www.w3.org/2000/svg';
const el = (tag, attrs = {}, parent) => { const n = document.createElementNS(NS, tag); for (const k in attrs) n.setAttribute(k, attrs[k]); if (parent) parent.appendChild(n); return n; };

function stats(h) {
  const fut = days.filter(x => x.i > 0 && x.i <= h);
  let inn = 0, out = 0;
  fut.forEach(x => x.ev.forEach(e => e.a > 0 ? inn += e.a : out += e.a));
  const min = fut.reduce((m, x) => x.b < m.b ? x : m, fut[0]);
  const firstNeg = fut.find(x => x.b < 0);
  return {inn, out, min, firstNeg};
}

function renderKpis() {
  const s = stats(horizon), now = byIndex(0);
  $('#kNow').textContent = rub(now.b);
  $('#kNowDate').textContent = `на ${dLong(today)}`;
  $('#kIn').textContent = rub(s.inn);
  $('#kInSub').textContent = `за ${horizon} дней`;
  $('#kOut').textContent = rub(-s.out);
  $('#kOutSub').textContent = `за ${horizon} дней`;
  $('#kMin').textContent = (s.min.b < 0 ? '−' : '') + rub(Math.abs(s.min.b));
  $('#kMinDate').textContent = dLong(s.min.d);
  $('#kMinBox').className = 'kpi ' + (s.min.b < 0 ? 'bad' : 'good');

  const a = $('#alert');
  if (s.firstNeg) {
    const deficit = -s.min.b;
    const suggest = Math.ceil(deficit * 1.15 / 50000) * 50000;
    const cause = days.filter(x => x.i > 0 && x.i <= s.min.i).flatMap(bigEvents).filter(e => e.a < 0).sort((p, q) => p.a - q.a)[0];
    a.innerHTML = `<div class="alert"><b>${dLong(s.firstNeg.d)} остаток уйдёт в минус</b>
      <p>В худший день, ${dLong(s.min.d)}, не хватит ${rub(deficit)}. Главная причина — ${cause.n.toLowerCase()}, ${rub(-cause.a)}.</p>
      <button class="btn btn--amber btn--sm" data-loan="${suggest}">Рассчитать кредит на ${rub(suggest)}</button></div>`;
  } else {
    a.innerHTML = `<div class="alert ok"><b>В ближайшие ${horizon} дней денег хватает</b>
      <p>Самый низкий остаток — ${rub(s.min.b)}, ${dLong(s.min.d)}. Попробуйте горизонт подлиннее.</p></div>`;
  }
  const list = days.filter(x => x.i > 0 && x.i <= horizon).flatMap(x => bigEvents(x).map(e => ({...e, d: x.d}))).slice(0, 6);
  $('#payList').innerHTML = list.map(e => `<li><time><b>${e.d.getDate()}</b>${MONTHS_S[e.d.getMonth()]}</time><span>${e.n}</span><em class="${e.a > 0 ? 'plus' : 'minus'}">${signed(e.a)}</em></li>`).join('');
}

function niceStep(range) {
  const steps = [100000, 250000, 500000, 1000000, 2000000, 5000000];
  return steps.find(s => range / s <= 5) || 5000000;
}

function renderChart() {
  const W = svg.clientWidth, H = svg.clientHeight;
  if (!W) return;
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.innerHTML = '';
  const narrow = W < 520;
  const pl = narrow ? 60 : 64, pr = narrow ? 12 : 22, pt = 14, pb = 28;
  const data = days.filter(x => x.i <= horizon);
  const vals = data.map(x => x.b);
  let lo = Math.min(0, ...vals), hi = Math.max(...vals);
  const step = niceStep(hi - lo);
  lo = Math.floor(lo / step) * step; hi = Math.ceil(hi / step) * step;
  if (lo === Math.min(0, ...vals) && lo < 0) lo -= step / 2;
  const X = i => pl + (i + PAST) / (PAST + horizon) * (W - pl - pr);
  const Y = v => pt + (hi - v) / (hi - lo) * (H - pt - pb);

  const defs = el('defs', {}, svg);
  const g = el('linearGradient', {id: 'ga', x1: 0, y1: 0, x2: 0, y2: 1}, defs);
  el('stop', {offset: 0, 'stop-color': '#F0B14A', 'stop-opacity': .28}, g);
  el('stop', {offset: 1, 'stop-color': '#F0B14A', 'stop-opacity': 0}, g);
  const cp = el('clipPath', {id: 'below'}, defs);
  el('rect', {x: 0, y: Y(0), width: W, height: Math.max(0, H - pb - Y(0))}, cp);

  // сетка
  for (let v = lo; v <= hi + 1; v += step) {
    const y = Y(v);
    el('line', {x1: pl, x2: W - pr, y1: y, y2: y, stroke: v === 0 ? 'rgba(236,232,221,.35)' : 'rgba(214,236,229,.07)', 'stroke-dasharray': v === 0 ? '0' : '0'}, svg);
    el('text', {x: pl - 10, y: y + 4, 'text-anchor': 'end'}, svg).textContent = v === 0 ? '0' : compact(v);
  }
  // подписи месяцев
  data.forEach(x => {
    if (x.d.getDate() === 1 || (!narrow && x.d.getDate() === 15)) {
      el('text', {x: X(x.i), y: H - 8, 'text-anchor': 'middle'}, svg).textContent = `${x.d.getDate()} ${MONTHS_S[x.d.getMonth()]}`;
    }
  });

  const pathOf = arr => arr.map((x, k) => `${k ? 'L' : 'M'}${X(x.i).toFixed(1)},${Y(x.b).toFixed(1)}`).join('');
  const past = data.filter(x => x.i <= 0), fut = data.filter(x => x.i >= 0);
  const pastD = pathOf(past), futD = pathOf(fut);

  el('path', {d: `${pastD}L${X(0)},${Y(lo)}L${X(-PAST)},${Y(lo)}Z`, fill: 'url(#ga)'}, svg);
  el('path', {d: `${futD}L${X(fut[fut.length - 1].i)},${Y(0)}L${X(0)},${Y(0)}Z`, fill: 'rgba(255,123,103,.22)', 'clip-path': 'url(#below)'}, svg);

  // сегодня
  el('line', {x1: X(0), x2: X(0), y1: pt, y2: H - pb, stroke: 'rgba(236,232,221,.25)', 'stroke-dasharray': '2 4'}, svg);
  const tl = el('text', {x: X(0) + 6, y: pt + 10, 'text-anchor': 'start'}, svg); tl.textContent = 'сегодня'; tl.style.fill = '#ECE8DD';

  const pastLine = el('path', {d: pastD, fill: 'none', stroke: '#F0B14A', 'stroke-width': 2.2, 'stroke-linejoin': 'round'}, svg);
  const futLine = el('path', {d: futD, fill: 'none', stroke: '#ECE8DD', 'stroke-width': 1.8, 'stroke-dasharray': '5 5', 'stroke-linejoin': 'round', opacity: .85}, svg);
  el('path', {d: futD, fill: 'none', stroke: '#FF7B67', 'stroke-width': 2.2, 'clip-path': 'url(#below)'}, svg);
  el('circle', {cx: X(0), cy: Y(byIndex(0).b), r: 4.5, fill: '#F0B14A', stroke: '#0D1B1E', 'stroke-width': 2}, svg);

  // единственный «момент» при загрузке: линия факта прорисовывается
  if (!drawn && !reduce) {
    const len = pastLine.getTotalLength();
    pastLine.style.strokeDasharray = len; pastLine.style.strokeDashoffset = len;
    futLine.style.opacity = 0;
    requestAnimationFrame(() => {
      pastLine.style.transition = 'stroke-dashoffset 1.4s cubic-bezier(.2,.7,.2,1)';
      pastLine.style.strokeDashoffset = 0;
      futLine.style.transition = 'opacity .8s 1.1s';
      futLine.style.opacity = .85;
    });
    drawn = true;
  }

  // наведение
  const guide = el('line', {y1: pt, y2: H - pb, stroke: 'rgba(236,232,221,.4)', opacity: 0}, svg);
  const dot = el('circle', {r: 5, fill: '#0D1B1E', 'stroke-width': 2.4, opacity: 0}, svg);
  const hit = el('rect', {x: pl, y: 0, width: W - pl - pr, height: H, fill: 'transparent'}, svg);
  const show = clientX => {
    const r = svg.getBoundingClientRect();
    const i = Math.max(-PAST, Math.min(horizon, Math.round((clientX - r.left - pl) / (W - pl - pr) * (PAST + horizon) - PAST)));
    const x = byIndex(i), px = X(i), py = Y(x.b);
    guide.setAttribute('x1', px); guide.setAttribute('x2', px); guide.setAttribute('opacity', 1);
    dot.setAttribute('cx', px); dot.setAttribute('cy', py); dot.setAttribute('opacity', 1);
    dot.setAttribute('stroke', x.b < 0 ? '#FF7B67' : i <= 0 ? '#F0B14A' : '#ECE8DD');
    const inflow = x.ev.filter(e => e.a > 0 && e.daily).reduce((s, e) => s + e.a, 0);
    const buys = x.ev.filter(e => e.a < 0 && e.daily).reduce((s, e) => s + e.a, 0);
    const rows = [...bigEvents(x).map(e => [e.n, e.a]), ['Выручка', inflow], ...(buys ? [['Закупки', buys]] : [])];
    tip.innerHTML = `<div class="d">${WD[x.d.getDay()]}, ${dLong(x.d)}${i > 0 ? ', прогноз' : i === 0 ? ', сегодня' : ''}</div>
      <div class="b ${x.b < 0 ? 'minus' : ''}">${x.b < 0 ? '−' : ''}${rub(Math.abs(x.b))}</div>
      <ul>${rows.map(([n, a]) => `<li><span>${n}</span><em class="${a > 0 ? 'plus' : 'minus'}">${signed(a)}</em></li>`).join('')}</ul>`;
    const tw = tip.offsetWidth, wr = wrap.getBoundingClientRect();
    let left = px + 16; if (left + tw > wr.width - 8) left = px - tw - 16;
    tip.style.left = Math.max(8, left) + 'px';
    tip.style.top = (svg.getBoundingClientRect().top - wr.top + 8) + 'px';
    tip.classList.add('on');
  };
  const hide = () => { tip.classList.remove('on'); guide.setAttribute('opacity', 0); dot.setAttribute('opacity', 0); };
  hit.addEventListener('pointermove', e => show(e.clientX));
  hit.addEventListener('pointerdown', e => show(e.clientX));
  hit.addEventListener('pointerleave', hide);
}

$$('#dash .seg button').forEach(b => b.addEventListener('click', () => {
  horizon = +b.dataset.h;
  $$('#dash .seg button').forEach(x => x.setAttribute('aria-pressed', x === b));
  renderKpis(); renderChart();
}));
new ResizeObserver(() => renderChart()).observe(svg);
renderKpis(); renderChart();

/* календарь и сообщение бота — из той же модели */
{
  const s = stats(60), focus = s.min.d;
  const y = focus.getFullYear(), m = focus.getMonth();
  $('#calTitle').textContent = `${MONTHS_N[m]} ${y}`;
  const first = new Date(y, m, 1), lead = (first.getDay() + 6) % 7, dim = new Date(y, m + 1, 0).getDate();
  let html = ['пн','вт','ср','чт','пт','сб','вс'].map(w => `<span class="wd">${w}</span>`).join('');
  for (let k = 0; k < lead; k++) html += '<span class="d x"></span>';
  for (let dd = 1; dd <= dim; dd++) {
    const date = new Date(y, m, dd);
    const x = days.find(z => z.d.getTime() === date.getTime());
    const cls = ['d'];
    let dots = '', title = `${dd} ${MONTHS_G[m]}`;
    if (x) {
      if (x.i === 0) cls.push('today');
      if (x.b < 0 && x.i > 0) cls.push('neg');
      dots = bigEvents(x).map(e => `<i class="${e.a > 0 ? 'in' : ''}"></i>`).join('');
      title += `: остаток ${x.b < 0 ? '−' : ''}${rub(Math.abs(x.b))}` + bigEvents(x).map(e => `, ${e.n} ${signed(e.a)}`).join('');
    }
    html += `<span class="${cls.join(' ')}" title="${title}">${dd}<span class="dots">${dots}</span></span>`;
  }
  $('#cal').innerHTML = html;
  const n = s.firstNeg ? s.firstNeg.i : 0;
  const big = bigEvents(byIndex(22))[0];
  $('#botMsg').innerHTML = s.firstNeg
    ? `<b>Через ${n} ${plural(n, 'день', 'дня', 'дней')} не хватит денег</b>${dLong(s.firstNeg.d)} остаток уйдёт в минус, в худший день — на ${rub(-s.min.b)}. Самый крупный платёж перед этим: ${big.n.toLowerCase()}, ${rub(-big.a)}.<small>09:00</small>`
    : `<b>Всё спокойно</b>Разрывов в ближайшие 60 дней нет.<small>09:00</small>`;
}

/* ---------- возможности: вкладки ---------- */
const tabs = $$('.feat-tab');
const openTab = t => {
  tabs.forEach(x => x.setAttribute('aria-selected', x === t));
  $$('.fpanel').forEach(p => p.classList.toggle('on', p.id === t.getAttribute('aria-controls')));
};
tabs.forEach((t, k) => {
  t.addEventListener('click', () => openTab(t));
  t.addEventListener('keydown', e => {
    const d = e.key === 'ArrowDown' || e.key === 'ArrowRight' ? 1 : e.key === 'ArrowUp' || e.key === 'ArrowLeft' ? -1 : 0;
    if (!d) return;
    e.preventDefault();
    const n = tabs[(k + d + tabs.length) % tabs.length]; n.focus(); openTab(n);
  });
});

/* ---------- калькулятор ---------- */
const calc = {amount: 800000, term: 12, type: 'ann'};
const A = {min: 100000, max: 5000000}, T = {min: 3, max: 24};
const rateFor = t => t <= 6 ? .239 : t <= 12 ? .259 : .279;
const amountR = $('#amount'), termR = $('#term'), amountIn = $('#amountIn'), termIn = $('#termIn');

function schedule({amount, term, type}) {
  const r = rateFor(term) / 12, rows = [];
  let bal = amount;
  const ann = amount * r / (1 - Math.pow(1 + r, -term));
  for (let k = 1; k <= term; k++) {
    const interest = bal * r;
    let principal = type === 'ann' ? ann - interest : amount / term;
    if (k === term) principal = bal;
    bal -= principal;
    rows.push({k, pay: principal + interest, principal, interest, bal: Math.max(0, bal)});
  }
  return rows;
}
const fill = (r, v, min, max) => r.style.setProperty('--p', ((v - min) / (max - min) * 100) + '%');

function renderCalc(fromInput) {
  const rows = schedule(calc), total = rows.reduce((s, x) => s + x.pay, 0);
  if (fromInput !== 'amount') amountIn.value = nf.format(calc.amount);
  if (fromInput !== 'term') termIn.value = calc.term;
  amountR.value = calc.amount; termR.value = calc.term;
  fill(amountR, calc.amount, A.min, A.max); fill(termR, calc.term, T.min, T.max);
  $('#termWord').textContent = plural(calc.term, 'месяц', 'месяца', 'месяцев');
  $('#rate').textContent = (rateFor(calc.term) * 100).toLocaleString('ru-RU') + '% годовых';
  if (calc.type === 'ann') {
    $('#payLabel').textContent = 'Платёж в месяц';
    $('#pay').textContent = rub(rows[0].pay);
    $('#paySub').textContent = `${calc.term} ${plural(calc.term, 'одинаковый платёж', 'одинаковых платежа', 'одинаковых платежей')}`;
  } else {
    $('#payLabel').textContent = 'Первый платёж';
    $('#pay').textContent = rub(rows[0].pay);
    $('#paySub').textContent = `дальше меньше, последний — ${rub(rows[rows.length - 1].pay)}`;
  }
  $('#over').textContent = rub(total - calc.amount);
  $('#total').textContent = rub(total);
  const maxPay = Math.max(...rows.map(x => x.pay));
  $('#bars').innerHTML = rows.map(x => `<div style="height:${(x.pay / maxPay * 100).toFixed(1)}%" title="${x.k}-й месяц: ${rub(x.pay)}"><i class="ii" style="height:${(x.interest / x.pay * 100).toFixed(1)}%"></i><i class="pi" style="flex:1"></i></div>`).join('');
  const start = new Date(today.getFullYear(), today.getMonth() + 1, 1);
  $('#schedBody').innerHTML = rows.map(x => {
    const d = new Date(start.getFullYear(), start.getMonth() + x.k - 1, 1);
    return `<tr><td>${MONTHS_S[d.getMonth()]} ${d.getFullYear()}</td><td>${nf.format(Math.round(x.pay))}</td><td>${nf.format(Math.round(x.principal))}</td><td>${nf.format(Math.round(x.interest))}</td><td>${nf.format(Math.round(x.bal))}</td></tr>`;
  }).join('');
  $('#calcApply').textContent = `Отправить заявку на ${rub(calc.amount)}`;
}
amountR.addEventListener('input', () => { calc.amount = +amountR.value; renderCalc(); });
termR.addEventListener('input', () => { calc.term = +termR.value; renderCalc(); });
amountIn.addEventListener('input', () => {
  const v = +amountIn.value.replace(/\D/g, '');
  amountIn.value = v ? nf.format(v) : '';
  if (v >= A.min && v <= A.max) { calc.amount = v; renderCalc('amount'); }
});
amountIn.addEventListener('change', () => {
  const v = +amountIn.value.replace(/\D/g, '') || A.min;
  calc.amount = Math.min(A.max, Math.max(A.min, Math.round(v / 10000) * 10000)); renderCalc();
});
termIn.addEventListener('input', () => {
  termIn.value = termIn.value.replace(/\D/g, '').slice(0, 2);
  const v = +termIn.value;
  if (v >= T.min && v <= T.max) { calc.term = v; renderCalc('term'); }
});
termIn.addEventListener('change', () => { calc.term = Math.min(T.max, Math.max(T.min, +termIn.value || 12)); renderCalc(); });
$$('#credit .seg button').forEach(b => b.addEventListener('click', () => {
  calc.type = b.dataset.type;
  $$('#credit .seg button').forEach(x => x.setAttribute('aria-pressed', x === b));
  renderCalc();
}));
renderCalc();

// из дашборда — в калькулятор с нужной суммой
document.addEventListener('click', e => {
  const b = e.target.closest('[data-loan]');
  if (!b) return;
  calc.amount = Math.min(A.max, Math.max(A.min, +b.dataset.loan));
  calc.term = 6; renderCalc();
  $('#credit').scrollIntoView({behavior: reduce ? 'auto' : 'smooth'});
});

/* ---------- тарифы ---------- */
const ptable = $('#ptable');
let period = 'm', plan = 'biz';
function renderPrices() {
  $$('.price', ptable).forEach(p => {
    const m = +p.dataset.m, y = +p.dataset.y, v = period === 'm' ? m : y;
    p.innerHTML = `${nf.format(v)}${NBSP}₽ <small>${v ? 'в месяц' : 'навсегда'}</small>`;
    const note = p.parentNode.querySelector('.price-note');
    note.textContent = !m ? 'один счёт, без ограничений по времени' : period === 'y' ? `${nf.format(y * 12)}${NBSP}₽ раз в год` : `или ${nf.format(y)}${NBSP}₽ при оплате за год`;
  });
  $('#planMobile').innerHTML = $(`thead .c-${plan}`, ptable).innerHTML;
}
$$('#pricing [data-period]').forEach(b => b.addEventListener('click', () => {
  period = b.dataset.period;
  $$('#pricing [data-period]').forEach(x => x.setAttribute('aria-pressed', x === b));
  renderPrices();
}));
$$('#pricing [data-plan]').forEach(b => b.addEventListener('click', () => {
  plan = b.dataset.plan; ptable.dataset.show = plan;
  $$('#pricing [data-plan]').forEach(x => x.setAttribute('aria-pressed', x === b));
  renderPrices();
}));
renderPrices();

/* ---------- отзывы ---------- */
const CASES = [
  {q: 'Раньше я узнавал о кассовом разрыве, когда бухгалтер звонила в день зарплаты. Теперь вижу его за три недели и спокойно переношу закупки.', c: 'Алексей Мартынов, владелец четырёх пекарен «Хлебник» в Казани', m: [['0', 'кассовых разрывов за полгода, до Сальдо было пять'], ['4 точки', 'в одном кабинете вместо четырёх таблиц']]},
  {q: 'Сверка с бухгалтером занимала два выходных в месяц. Теперь она сама заходит в Сальдо, а я отвечаю на пару вопросов в чате.', c: 'Ольга Ким, студия маникюра «Лак» в Новосибирске', m: [['1 час', 'на сверку в месяц вместо двух дней'], ['12 статей', 'расходов настроила один раз']]},
  {q: 'Перед сезоном шин не хватало на закупку. Отправил заявку из кабинета вечером, через 11 минут пришло одобрение, утром деньги были на счёте.', c: 'Руслан Абдуллаев, магазин автозапчастей в Уфе', m: [['11 минут', 'до одобрения кредита на 1,2 млн ₽'], ['+34%', 'выручки в сезон благодаря закупке']]}
];
const caseView = $('#caseView');
const showCase = k => {
  const c = CASES[k];
  caseView.classList.remove('swap'); void caseView.offsetWidth; caseView.classList.add('swap');
  caseView.innerHTML = `<blockquote>«${c.q}»</blockquote><cite>${c.c}</cite><div class="case-metrics">${c.m.map(([b, s]) => `<div><b>${b}</b><span>${s}</span></div>`).join('')}</div>`;
  $$('.case-btn').forEach(b => b.setAttribute('aria-selected', +b.dataset.case === k));
};
$$('.case-btn').forEach(b => b.addEventListener('click', () => showCase(+b.dataset.case)));
showCase(0);

/* ---------- FAQ: поиск ---------- */
const qas = $$('.qa');
qas.forEach(q => { const s = $('summary', q); s.dataset.t = s.textContent; });
const norm = s => s.toLowerCase().replace(/ё/g, 'е');
const esc = s => s.replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
$('#faqSearch').addEventListener('input', e => {
  const q = norm(e.target.value.trim());
  let shown = 0;
  qas.forEach(item => {
    const s = $('summary', item), text = norm(s.dataset.t + ' ' + $('p', item).textContent);
    const hit = !q || text.includes(q);
    item.hidden = !hit; if (hit) shown++;
    const t = s.dataset.t, idx = q ? norm(t).indexOf(q) : -1;
    s.innerHTML = idx >= 0 ? esc(t.slice(0, idx)) + '<mark>' + esc(t.slice(idx, idx + q.length)) + '</mark>' + esc(t.slice(idx + q.length)) : esc(t);
    if (q && hit && idx < 0) item.open = true;
    if (!q) item.open = false;
  });
  const empty = $('#faqEmpty');
  empty.hidden = shown > 0;
  empty.textContent = shown ? '' : `По запросу «${e.target.value.trim()}» ничего нет. Напишите в чат поддержки — ответим за 5 минут.`;
});

/* ---------- формы ---------- */
const maskPhone = input => input.addEventListener('input', () => {
  let d = input.value.replace(/\D/g, '');
  if (!d) { input.value = ''; return; }
  if (d[0] === '8') d = '7' + d.slice(1);
  if (d[0] !== '7') d = '7' + d;
  d = d.slice(0, 11);
  const p = [d.slice(1, 4), d.slice(4, 7), d.slice(7, 9), d.slice(9, 11)];
  input.value = '+7' + (p[0] ? ' ' + p[0] : '') + (p[1] ? ' ' + p[1] : '') + (p[2] ? '-' + p[2] : '') + (p[3] ? '-' + p[3] : '');
});
maskPhone($('#heroPhone')); maskPhone($('#phone'));

function innValid(v) {
  const d = v.split('').map(Number);
  const chk = coefs => coefs.reduce((s, c, k) => s + c * d[k], 0) % 11 % 10;
  if (d.length === 10) return chk([2, 4, 10, 3, 5, 9, 4, 6, 8]) === d[9];
  if (d.length === 12) return chk([7, 2, 4, 10, 3, 5, 9, 4, 6, 8]) === d[10] && chk([3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8]) === d[11];
  return false;
}

const form = $('#applyForm'), fsteps = $$('.fstep', form), stepsNav = $$('#steps li');
let step = 1;
const go = n => {
  step = n;
  fsteps.forEach(f => f.classList.toggle('on', +f.dataset.step === n));
  stepsNav.forEach((li, k) => { li.className = k + 1 < n ? 'done' : k + 1 === n ? 'cur' : ''; });
  const first = $(`.fstep[data-step="${n}"] input, .fstep[data-step="${n}"] button`, form);
  if (first && n > 1) first.focus({preventScroll: true});
};
const setErr = (key, msg) => {
  const f = $(`[data-f="${key}"]`, form);
  f.classList.toggle('err', !!msg); $('.msg', f).textContent = msg || '';
  return !msg;
};
const inn = $('#inn');
inn.addEventListener('input', () => { inn.value = inn.value.replace(/\D/g, '').slice(0, 12); setErr('inn', ''); });
['fname', 'phone', 'email'].forEach(id => $('#' + id).addEventListener('input', () => setErr(id === 'fname' ? 'name' : id, '')));

const validate = n => {
  if (n === 1) {
    const v = inn.value;
    if (!v) return setErr('inn', 'Введите ИНН компании или ИП');
    if (v.length !== 10 && v.length !== 12) return setErr('inn', `В ИНН 10 цифр у ООО и 12 у ИП, сейчас ${v.length}`);
    if (!innValid(v)) return setErr('inn', 'Контрольная цифра не сходится — проверьте, нет ли опечатки');
    return setErr('inn', '');
  }
  if (n === 2) {
    const a = setErr('name', $('#fname').value.trim() ? '' : 'Напишите, как к вам обращаться');
    const b = setErr('phone', $('#phone').value.replace(/\D/g, '').length === 11 ? '' : 'Нужен номер полностью: +7 и 10 цифр');
    const c = setErr('email', /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test($('#email').value.trim()) ? '' : 'Проверьте адрес почты, например name@company.ru');
    return a && b && c;
  }
  return true;
};
$$('[data-next]', form).forEach(b => b.addEventListener('click', () => { if (validate(step)) go(step + 1); else $('.err input', form)?.focus(); }));
$$('[data-prev]', form).forEach(b => b.addEventListener('click', () => go(step - 1)));
form.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.tagName === 'INPUT' && step < 3) { e.preventDefault(); $(`.fstep[data-step="${step}"] [data-next]`, form).click(); }
});
const need = $('#needCredit'), cAmount = $('#cAmount');
need.addEventListener('change', () => form.classList.toggle('credit-on', need.checked));
cAmount.addEventListener('input', () => { const v = +cAmount.value.replace(/\D/g, ''); cAmount.value = v ? nf.format(v) : ''; });

form.addEventListener('submit', e => {
  e.preventDefault();
  const credit = need.checked && +cAmount.value.replace(/\D/g, '');
  const termSel = $('#cTerm');
  const rows = [
    ['ИНН', inn.value], ['Сфера', $('#kind').value], ['Оборот', $('#turnover').value],
    ['Контакт', `${$('#fname').value.trim()}, ${$('#phone').value}`], ['Почта', $('#email').value.trim()],
    ['Кредит', credit ? `${rub(credit)} на ${termSel.options[termSel.selectedIndex].text}` : 'не нужен']
  ];
  $('#summary').innerHTML = rows.map(([a, b]) => `<li><span>${a}</span><b>${esc(b)}</b></li>`).join('');
  $('#doneTitle').textContent = 'Заявка принята';
  $('#doneText').textContent = `Ссылка для подключения банков уже на ${$('#email').value.trim()}. ` + (credit ? 'Предложения банков-партнёров придут в кабинет в течение 15 минут.' : 'Менеджер позвонит, чтобы помочь с настройкой.');
  go(4);
  stepsNav.forEach(li => li.className = 'done');
});
$('#restart').addEventListener('click', () => { form.reset(); form.classList.remove('credit-on'); go(1); inn.focus(); });

// из калькулятора — в заявку
$('#calcApply').addEventListener('click', () => {
  need.checked = true; form.classList.add('credit-on');
  cAmount.value = nf.format(calc.amount);
  const sel = $('#cTerm');
  if (![...sel.options].some(o => +o.value === calc.term)) sel.add(new Option(`${calc.term} ${plural(calc.term, 'месяц', 'месяца', 'месяцев')}`, calc.term));
  sel.value = calc.term;
});
// с первого экрана — в заявку с телефоном
$('#heroForm').addEventListener('submit', e => {
  e.preventDefault();
  $('#phone').value = $('#heroPhone').value;
  $('#apply').scrollIntoView({behavior: reduce ? 'auto' : 'smooth'});
  setTimeout(() => inn.focus({preventScroll: true}), reduce ? 0 : 600);
});
})();
