/* Пенка — общий скрипт */
(() => {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* мобильное меню */
  const burger = $('#burger');
  if (burger) {
    const set = open => {
      document.body.classList.toggle('menu-open', open);
      burger.setAttribute('aria-expanded', open);
      burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    };
    burger.addEventListener('click', () => set(!document.body.classList.contains('menu-open')));
    $$('.mnav a').forEach(a => a.addEventListener('click', () => set(false)));
    addEventListener('keydown', e => e.key === 'Escape' && set(false));
  }

  /* «Открыто сейчас» — по времени Екатеринбурга */
  const open = $('.open-now');
  if (open) {
    const now = new Date(new Date().toLocaleString('en-US', {timeZone: 'Asia/Yekaterinburg'}));
    const d = now.getDay(), m = now.getHours() * 60 + now.getMinutes();
    const from = (d === 0 || d === 6) ? 9 * 60 : 7 * 60 + 30;
    const isOpen = m >= from && m < 22 * 60;
    open.classList.toggle('closed', !isOpen);
    const next = m < from ? (from === 540 ? '9:00' : '7:30') : ((d === 5 || d === 6) ? '9:00' : '7:30');
    $('span', open).textContent = isOpen ? 'Открыто до 22:00' : `Закрыто, откроемся в ${next}`;
  }

  /* появление блоков */
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), {threshold: .12, rootMargin: '0px 0px -30px 0px'});
  $$('.pop').forEach(el => io.observe(el));

  /* глаза маскота следят за курсором */
  const pupils = $$('[data-pupil]');
  if (pupils.length && !reduce) {
    const look = (x, y) => pupils.forEach(p => {
      const r = p.parentNode.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const a = Math.atan2(y - cy, x - cx), dist = Math.min(1, Math.hypot(x - cx, y - cy) / 300);
      p.setAttribute('transform', `translate(${Math.cos(a) * 5 * dist} ${Math.sin(a) * 5 * dist})`);
    });
    addEventListener('pointermove', e => look(e.clientX, e.clientY), {passive: true});
    // иногда моргает
    const lids = $$('[data-lid]');
    setInterval(() => {
      lids.forEach(l => l.animate([{transform: 'scaleY(0)'}, {transform: 'scaleY(1)'}, {transform: 'scaleY(0)'}], {duration: 220}));
    }, 4200);
  }

  /* карта гостя: 8-й кофе в подарок */
  const stamps = $('#stamps');
  if (stamps) {
    const cells = $$('.stamp', stamps), msg = $('#stampMsg'), reset = $('#stampReset');
    let n = 2;
    const draw = () => {
      cells.forEach((c, i) => c.classList.toggle('on', i < n));
      const left = cells.length - n;
      msg.textContent = left === 0
        ? 'Восьмой кофе — за наш счёт! Покажите карту бариста.'
        : left === 1 ? 'Ещё один кофе — и следующий бесплатно'
        : `До бесплатного кофе: ${left} ${left < 5 ? 'чашки' : 'чашек'}`;
      stamps.classList.toggle('full', left === 0);
    };
    cells.forEach((c, i) => c.addEventListener('click', () => { n = (n === i + 1) ? i : i + 1; draw(); }));
    $('#stampAdd').addEventListener('click', () => { n = Math.min(cells.length, n + 1); draw(); });
    reset.addEventListener('click', () => { n = 0; draw(); });
    draw();
  }

  /* страница меню */
  const menuGrid = $('#menuGrid');
  if (menuGrid) {
    const M = window.MENU;
    const state = {cat: 'coffee', diet: new Set(), size: 1};
    const labels = {plant: 'можно на растительном', vegan: 'веган', gf: 'без глютена'};
    const render = () => {
      const items = M.filter(i => i.cat === state.cat && [...state.diet].every(d => i.tags.includes(d)));
      $('#sizeSwitch').hidden = !['coffee', 'drinks'].includes(state.cat);
      menuGrid.innerHTML = items.length ? items.map((i, k) => {
        const price = i.p.length > 1 ? i.p[Math.min(state.size, i.p.length - 1)] : i.p[0];
        const vol = i.v ? i.v[Math.min(state.size, i.v.length - 1)] : i.w || '';
        return `<article class="card item card--hover" style="--c:var(--${i.c});animation-delay:${k * 45}ms">
          <div class="item__art"><svg viewBox="0 0 120 120" aria-hidden="true"><use href="#ic-${i.icon}"/></svg>
            ${i.badge ? `<span class="item__badge">${i.badge}</span>` : ''}</div>
          <div class="item__body">
            <h3>${i.n}</h3><p>${i.d}</p>
            <div class="item__tags">${i.tags.filter(t => labels[t]).map(t => `<span>${labels[t]}</span>`).join('')}</div>
            <div class="item__foot"><span class="item__vol">${vol}</span><b>${price} ₽</b></div>
          </div></article>`;
      }).join('') : `<p class="empty">Под такой фильтр ничего нет. Попробуйте убрать одну галочку — или спросите бариста, он что-нибудь придумает.</p>`;
      $$('.tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.cat === state.cat));
      $$('#sizeSwitch button').forEach(b => b.setAttribute('aria-pressed', +b.dataset.size === state.size));
      $('#count').textContent = items.length;
    };
    $$('.tabs button').forEach(b => b.addEventListener('click', () => { state.cat = b.dataset.cat; render(); }));
    $$('.chips input').forEach(c => c.addEventListener('change', () => { c.checked ? state.diet.add(c.value) : state.diet.delete(c.value); render(); }));
    $$('#sizeSwitch button').forEach(b => b.addEventListener('click', () => { state.size = +b.dataset.size; render(); }));
    const hash = location.hash.slice(1);
    if (M.some(i => i.cat === hash)) state.cat = hash;
    render();
  }
})();
