/**
 * Бот барбершопа «Бритва» — принимает записи из Mini App.
 * Node.js 18+, без внешних зависимостей.
 *
 *   BOT_TOKEN=123:ABC WEBAPP_URL=https://you.github.io/britva/ ADMIN_CHAT_ID=-1001234567890 node bot.js
 *
 * Что умеет:
 *  • /start — кнопка «Записаться», открывающая Mini App, и кнопка меню бота;
 *  • принимает запись двумя способами:
 *      1) web_app_data — если приложение открыто кнопкой клавиатуры (сервер не нужен);
 *      2) POST /api/booking — если открыто из меню; проверяет подпись initData;
 *  • не даёт записать двоих на одно время к одному мастеру;
 *  • подтверждает запись клиенту, дублирует администратору и напоминает за 2 часа.
 *
 * Записи хранятся в памяти процесса — для продакшена замените на базу (SQLite, Postgres).
 */
'use strict';
const http = require('node:http');
const crypto = require('node:crypto');

const {BOT_TOKEN, WEBAPP_URL, ADMIN_CHAT_ID, PORT = 8080} = process.env;
if (!BOT_TOKEN || !WEBAPP_URL) {
  console.error('Нужны переменные BOT_TOKEN и WEBAPP_URL. См. README.');
  process.exit(1);
}
const API = `https://api.telegram.org/bot${BOT_TOKEN}/`;
const SALON_UTC_OFFSET = 7; // Новосибирск
const OPEN = 10;
const MASTERS = {artem: 'Артём Ковалёв', denis: 'Денис Юсупов', mira: 'Мира Лим', gleb: 'Глеб Орлов'};

async function tg(method, body) {
  const r = await fetch(API + method, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  const j = await r.json();
  if (!j.ok) console.warn(method, j.description);
  return j;
}
const esc = s => String(s ?? '').replace(/[&<>]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;'}[c]));
const time = c => `${OPEN + Math.floor(c / 2)}:${c % 2 ? '30' : '00'}`;
const dateRu = k => { const [y, m, d] = k.split('-'); return `${d}.${m}.${y}`; };

/* ---------- записи ---------- */
const bookings = new Map(); // id → запись
function conflicts(b) {
  for (const x of bookings.values()) {
    if (x.masterId === b.masterId && x.date === b.date && b.cell < x.cell + x.cells && x.cell < b.cell + b.cells) return true;
  }
  return false;
}
function validBooking(b) {
  return b && typeof b === 'object' && MASTERS[b.masterId] && /^\d{4}-\d{2}-\d{2}$/.test(b.date) &&
    Number.isInteger(b.cell) && b.cell >= 0 && b.cell < 22 && Number.isInteger(b.cells) && b.cells > 0 && b.cells <= 4 &&
    typeof b.name === 'string' && b.name.length < 80 && String(b.phone).replace(/\D/g, '').length === 11;
}
async function accept(b, user) {
  if (!validBooking(b)) return {status: 400, error: 'Некорректная запись'};
  if (conflicts(b)) return {status: 409, error: 'Это время уже заняли'};
  b.userId = user && user.id;
  bookings.set(b.id, b);

  const when = `${dateRu(b.date)}, ${time(b.cell)}–${time(b.cell + b.cells)}`;
  if (b.userId) {
    await tg('sendMessage', {
      chat_id: b.userId, parse_mode: 'HTML',
      text: `<b>Вы записаны</b>\n\n${esc(b.service)}\n${when}\nМастер: ${esc(b.master)}\nК оплате: ${b.price} ₽\n\nНовосибирск, Красный проспект, 77`,
      reply_markup: {inline_keyboard: [[{text: 'Отменить запись', callback_data: 'cancel:' + b.id}]]}
    });
  }
  if (ADMIN_CHAT_ID) {
    const who = user && user.username ? ` (@${esc(user.username)})` : '';
    await tg('sendMessage', {
      chat_id: ADMIN_CHAT_ID, parse_mode: 'HTML',
      text: `<b>Новая запись</b>\n\n${esc(b.name)}${who}, ${esc(b.phone)}\n${esc(b.service)} — ${esc(b.master)}\n${when}\n${b.price} ₽` + (b.note ? `\n\nПожелание: ${esc(b.note)}` : '')
    });
  }
  if (b.remind && b.userId) scheduleReminder(b);
  return {status: 200};
}
function scheduleReminder(b) {
  const [y, m, d] = b.date.split('-').map(Number);
  const startUtc = Date.UTC(y, m - 1, d, OPEN + Math.floor(b.cell / 2) - SALON_UTC_OFFSET, b.cell % 2 ? 30 : 0);
  const delay = startUtc - 2 * 3600e3 - Date.now();
  if (delay <= 0 || delay > 14 * 24 * 3600e3) return;
  setTimeout(() => {
    if (!bookings.has(b.id)) return;
    tg('sendMessage', {chat_id: b.userId, text: `Напоминаем: сегодня в ${time(b.cell)} — ${b.service.toLowerCase()} у мастера ${b.master}. Красный проспект, 77. Ждём!`});
  }, delay);
}

/* ---------- проверка подписи initData ---------- */
// https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
function checkInitData(initData) {
  const p = new URLSearchParams(initData);
  const hash = p.get('hash');
  if (!hash) return null;
  p.delete('hash');
  const dataCheck = [...p.entries()].map(([k, v]) => `${k}=${v}`).sort().join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
  const calc = crypto.createHmac('sha256', secret).update(dataCheck).digest('hex');
  const a = Buffer.from(calc, 'hex'), b = Buffer.from(hash, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  if (Date.now() / 1000 - Number(p.get('auth_date')) > 24 * 3600) return null; // старше суток
  try { return JSON.parse(p.get('user')); } catch { return null; }
}

/* ---------- HTTP API для Mini App ---------- */
const origin = new URL(WEBAPP_URL).origin;
http.createServer(async (req, res) => {
  const cors = {'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type'};
  const send = (status, data) => { res.writeHead(status, {...cors, 'Content-Type': 'application/json'}); res.end(JSON.stringify(data)); };
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  if (req.method !== 'POST' || req.url !== '/api/booking') return send(404, {ok: false});

  let raw = '';
  for await (const chunk of req) { raw += chunk; if (raw.length > 10000) return send(413, {ok: false}); }
  let body;
  try { body = JSON.parse(raw); } catch { return send(400, {ok: false}); }

  const user = checkInitData(body.initData || '');
  if (!user) return send(401, {ok: false, error: 'Подпись Telegram не прошла проверку'});
  const r = await accept(body.booking, user);
  send(r.status, {ok: r.status === 200, error: r.error});
}).listen(PORT, () => console.log(`API: http://localhost:${PORT}/api/booking`));

/* ---------- long polling ---------- */
async function onUpdate(u) {
  const msg = u.message;
  if (msg && msg.text === '/start') {
    await tg('sendMessage', {
      chat_id: msg.chat.id,
      text: 'Здравствуйте! Это барбершоп «Бритва». Записаться можно за полминуты — нажмите кнопку ниже.',
      reply_markup: {keyboard: [[{text: 'Записаться', web_app: {url: WEBAPP_URL}}]], resize_keyboard: true}
    });
  }
  if (msg && msg.web_app_data) {
    let b;
    try { b = JSON.parse(msg.web_app_data.data); } catch { b = null; }
    const r = await accept(b, msg.from);
    if (r.status !== 200) await tg('sendMessage', {chat_id: msg.chat.id, text: `Не получилось записаться: ${r.error}. Откройте запись и выберите другое время.`});
  }
  const cb = u.callback_query;
  if (cb && cb.data && cb.data.startsWith('cancel:')) {
    const b = bookings.get(cb.data.slice(7));
    if (b && b.userId === cb.from.id) {
      bookings.delete(b.id);
      await tg('editMessageText', {chat_id: cb.message.chat.id, message_id: cb.message.message_id, text: `Запись на ${dateRu(b.date)}, ${time(b.cell)} отменена.`});
      if (ADMIN_CHAT_ID) await tg('sendMessage', {chat_id: ADMIN_CHAT_ID, text: `Отмена: ${b.name}, ${dateRu(b.date)} ${time(b.cell)}, ${b.master}`});
    }
    await tg('answerCallbackQuery', {callback_query_id: cb.id, text: b ? 'Запись отменена' : 'Запись не найдена'});
  }
}

(async function poll() {
  await tg('setChatMenuButton', {menu_button: {type: 'web_app', text: 'Записаться', web_app: {url: WEBAPP_URL}}});
  console.log('Бот запущен');
  let offset = 0;
  for (;;) {
    try {
      const r = await tg('getUpdates', {offset, timeout: 30, allowed_updates: ['message', 'callback_query']});
      for (const u of r.result || []) { offset = u.update_id + 1; onUpdate(u).catch(e => console.error(e)); }
    } catch (e) {
      console.error('Сеть недоступна, повтор через 5 с', e.message);
      await new Promise(r => setTimeout(r, 5000));
    }
  }
})();
