/* Бритва — Telegram Mini App для записи в барбершоп */

// Адрес вашего сервера (bot/bot.js). Если пусто — запись передаётся боту через
// tg.sendData (когда приложение открыто кнопкой клавиатуры) или сохраняется локально (демо).
const CONFIG = {apiUrl: ''};

(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const nf = new Intl.NumberFormat('ru-RU');
const rub = n => nf.format(n) + ' ₽';
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));

/* ---------- Telegram или браузер ---------- */
const tg = window.Telegram && window.Telegram.WebApp;
const inTG = !!(tg && (tg.initData || tg.platform !== 'unknown'));
const root = document.documentElement;
const ver = v => inTG && tg.isVersionAtLeast && tg.isVersionAtLeast(v);

if (inTG) {
  tg.ready();
  tg.expand();
  if (ver('6.1')) { tg.setHeaderColor('secondary_bg_color'); tg.setBackgroundColor('secondary_bg_color'); }
  if (ver('7.7') && tg.disableVerticalSwipes) tg.disableVerticalSwipes();
} else {
  root.classList.add('demo');
  const dark = matchMedia('(prefers-color-scheme: dark)').matches;
  const setTheme = t => {
    root.classList.toggle('dark', t === 'dark');
    $$('.sc-theme button').forEach(b => b.setAttribute('aria-pressed', b.dataset.theme === t));
  };
  $$('.sc-theme button').forEach(b => b.addEventListener('click', () => setTheme(b.dataset.theme)));
  setTheme(dark ? 'dark' : 'light');
}

/* ---------- обёртки над кнопками и вибрацией Telegram ---------- */
const fakeMain = $('#fakeMain');
let mainHandler = null;
const UI = {
  main(text, enabled, onClick) {
    if (inTG) {
      if (mainHandler) tg.MainButton.offClick(mainHandler);
      mainHandler = onClick;
      tg.MainButton.onClick(mainHandler);
      tg.MainButton.setParams({text, is_active: enabled, is_visible: true});
      if (ver('6.1')) tg.MainButton.setParams({color: enabled ? tg.themeParams.button_color : tg.themeParams.hint_color});
    } else {
      fakeMain.hidden = false; fakeMain.textContent = text; fakeMain.disabled = !enabled;
      fakeMain.onclick = () => enabled && onClick();
    }
  },
  hideMain() { inTG ? tg.MainButton.hide() : (fakeMain.hidden = true); },
  progress(on) {
    if (inTG) on ? tg.MainButton.showProgress(false) : tg.MainButton.hideProgress();
    else { fakeMain.classList.toggle('loading', on); fakeMain.disabled = on; }
  },
  back(show) {
    if (inTG && ver('6.1')) show ? tg.BackButton.show() : tg.BackButton.hide();
    root.classList.toggle('can-back', show);
  },
  tick() { if (ver('6.1')) tg.HapticFeedback.selectionChanged(); },
  buzz(type) { if (ver('6.1')) tg.HapticFeedback.notificationOccurred(type); },
  confirm(text, cb) { ver('6.2') ? tg.showConfirm(text, cb) : cb(window.confirm(text)); },
  open(url) { inTG ? tg.openLink(url) : window.open(url, '_blank', 'noopener'); }
};
if (inTG && ver('6.1')) tg.BackButton.onClick(() => back());
$('#fakeBack').addEventListener('click', () => back());
$('#fakeClose').addEventListener('click', () => toast('В Telegram эта кнопка закрывает приложение'));

/* ---------- хранилище: облако Telegram, иначе localStorage ---------- */
const KEY = 'britva_bookings';
let memory = [];
const store = {
  load(cb) {
    if (ver('6.9')) return tg.CloudStorage.getItem(KEY, (e, v) => cb(e || !v ? [] : safeParse(v)));
    try { cb(safeParse(localStorage.getItem(KEY)) || []); } catch { cb(memory); }
  },
  save(list) {
    const raw = JSON.stringify(list.slice(-20));
    if (ver('6.9')) return tg.CloudStorage.setItem(KEY, raw);
    try { localStorage.setItem(KEY, raw); } catch { memory = list; }
  }
};
function safeParse(v) { try { return JSON.parse(v) || []; } catch { return []; } }

/* ---------- данные ---------- */
const ICONS = {
  scissors: '<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M8.2 15L19 3M15.8 15L5 3"/>',
  clipper: '<rect x="7" y="7" width="10" height="15" rx="3"/><path d="M6 3h12v4H6zM9 3v4M12 3v4M15 3v4"/>',
  kid: '<circle cx="12" cy="8" r="4"/><path d="M5 21c0-4 3-7 7-7s7 3 7 7"/><path d="M9 5c1 1.5 3 2 5 1"/>',
  beard: '<path d="M5 6v4c0 6 3 11 7 11s7-5 7-11V6"/><path d="M9 14c1.5 1 4.5 1 6 0"/><path d="M5 6c2 1 4 1 7-1 3 2 5 2 7 1"/>',
  razor: '<path d="M4 20l9-9"/><path d="M11 3h9v4l-9 7-3-3z"/>',
  combo: '<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M8.2 15L19 3M15.8 15L5 3"/><path d="M12 20h0"/>',
  duo: '<circle cx="8" cy="7" r="3"/><circle cx="17" cy="10" r="2.4"/><path d="M2 21c0-4 2.7-7 6-7s6 3 6 7M13 21c0-3 1.8-5 4-5s4 2 4 5"/>',
  any: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>'
};
const icon = (k, bg) => `<span class="ico" style="background:${bg}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[k]}</svg></span>`;
const SERVICES = [
  {g: 'Стрижки', items: [
    {id: 'cut', n: 'Мужская стрижка', note: 'мытьё головы и укладка', d: 60, p: 1800, ic: 'scissors', c: '#B8612E'},
    {id: 'buzz', n: 'Стрижка машинкой', note: 'одна насадка или переход', d: 30, p: 1100, ic: 'clipper', c: '#6E7C87'},
    {id: 'kid', n: 'Детская стрижка', note: 'до 12 лет, мультики на планшете', d: 45, p: 1200, ic: 'kid', c: '#4F9D7A'}
  ]},
  {g: 'Борода и бритьё', items: [
    {id: 'beard', n: 'Моделирование бороды', note: 'форма, контур, масло', d: 45, p: 1300, ic: 'beard', c: '#8C6A4F'},
    {id: 'shave', n: 'Королевское бритьё', note: 'горячее полотенце, опасная бритва', d: 45, p: 1700, ic: 'razor', c: '#5B6BAF'}
  ]},
  {g: 'Комплексы', items: [
    {id: 'combo', n: 'Стрижка и борода', note: 'выгоднее на 300 ₽', d: 90, p: 2800, old: 3100, hit: true, ic: 'combo', c: '#1F1B18'},
    {id: 'duo', n: 'Отец и сын', note: 'две стрижки подряд у одного мастера', d: 90, p: 2700, ic: 'duo', c: '#A34F6B'}
  ]}
];
const SVC = SERVICES.flatMap(g => g.items);
const MASTERS = [
  {id: 'artem', n: 'Артём Ковалёв', short: 'Артём', rank: 'Топ-барбер', k: 1.2, rating: '4,98', reviews: 312, off: 2, c: '#B8612E'},
  {id: 'denis', n: 'Денис Юсупов', short: 'Денис', rank: 'Барбер', k: 1, rating: '4,93', reviews: 187, off: 1, c: '#4F7A9D'},
  {id: 'mira', n: 'Мира Лим', short: 'Мира', rank: 'Барбер', k: 1, rating: '4,95', reviews: 146, off: 3, c: '#7D5BA6'},
  {id: 'gleb', n: 'Глеб Орлов', short: 'Глеб', rank: 'Младший барбер', k: .85, rating: '4,88', reviews: 64, off: 4, c: '#4F9D7A'}
];
const MS = id => MASTERS.find(m => m.id === id);
const priceFor = (svc, m) => Math.round(svc.p * (m ? m.k : 1) / 50) * 50;
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c; };

/* ---------- время: барбершоп в Новосибирске, 10:00–21:00 ---------- */
const TZ = 'Asia/Novosibirsk', OPEN = 10, CLOSE = 21, CELLS = (CLOSE - OPEN) * 2;
const salonNow = () => new Date(new Date().toLocaleString('en-US', {timeZone: TZ}));
const WD = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
const WD_FULL = ['воскресенье', 'понедельник', 'вторник', 'среду', 'четверг', 'пятницу', 'субботу'];
const MON = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const MON_S = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const keyOf = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const fromKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const cellTime = c => `${OPEN + Math.floor(c / 2)}:${c % 2 ? '30' : '00'}`;
const DAYS = (() => { const t = salonNow(); t.setHours(0, 0, 0, 0); return Array.from({length: 14}, (_, i) => { const d = new Date(t); d.setDate(t.getDate() + i); return d; }); })();
const dayLabel = (d, i) => i === 0 ? 'сегодня' : i === 1 ? 'завтра' : WD[d.getDay()];

// детерминированная «занятость» — одинаковая при каждом открытии
const hash = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; };
let bookings = [];
function cellBusy(m, key, c) {
  if (bookings.some(b => b.masterId === m.id && b.date === key && c >= b.cell && c < b.cell + b.cells && b.id !== S.rescheduling)) return true;
  const base = hash(m.id + key + c);
  const eveningRush = c >= 14 ? .12 : 0; // вечером занято чаще
  return base < .38 + eveningRush;
}
function masterFree(m, key, start, cells) {
  const d = fromKey(key);
  if (d.getDay() === m.off) return false;
  if (start + cells > CELLS) return false;
  if (key === keyOf(DAYS[0])) {
    const now = salonNow(), nowCell = (now.getHours() - OPEN) * 2 + (now.getMinutes() >= 30 ? 1 : 0) + 1;
    if (start <= nowCell) return false;
  }
  for (let c = start; c < start + cells; c++) if (cellBusy(m, key, c)) return false;
  return true;
}
const freeMasters = (key, start, cells, only) => MASTERS.filter(m => (!only || m.id === only) && masterFree(m, key, start, cells));
function nearest(onlyId, cells) {
  for (let i = 0; i < DAYS.length; i++) {
    const key = keyOf(DAYS[i]);
    for (let c = 0; c < CELLS; c++) if (freeMasters(key, c, cells, onlyId).length) return {i, key, c};
  }
  return null;
}
const nearestText = n => n ? `${dayLabel(DAYS[n.i], n.i)} в ${cellTime(n.c)}` : 'нет окон на 2 недели';

/* ---------- состояние и навигация ---------- */
const S = {service: null, master: null, date: null, cell: null, rescheduling: null};
const cellsOf = svc => svc.d / 30;
const ORDER = ['home', 'master', 'time', 'confirm', 'done'];
let view = 'home';
function go(v, isBack = false) {
  $$('.view').forEach(el => { el.classList.toggle('on', el.dataset.view === v); el.classList.toggle('back', isBack); });
  view = v;
  UI.back(v !== 'home' && v !== 'done');
  ({home: renderHome, master: renderMasters, time: renderTime, confirm: renderConfirm, done: () => {}})[v]();
  const sc = $('#screen'); sc.scrollTop = 0; window.scrollTo(0, 0);
}
function back() {
  if (view === 'home' || view === 'done') return;
  UI.tick();
  go(ORDER[ORDER.indexOf(view) - 1], true);
}

/* ---------- 1. услуги ---------- */
let tab = 'book';
function renderHome() {
  $('#tabBook').hidden = tab !== 'book';
  $('#tabMine').hidden = tab !== 'mine';
  $$('.tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === tab));
  const upcoming = upcomingBookings();
  $('#mineCount').textContent = upcoming.length || '';
  if (tab === 'mine') { renderMine(upcoming); UI.hideMain(); return; }
  $('#services').innerHTML = SERVICES.map(g => `<p class="caption-up">${g.g}</p><div class="section" role="radiogroup" aria-label="${g.g}">${
    g.items.map(s => `<button class="item" role="radio" aria-checked="${S.service === s.id}" data-svc="${s.id}">${icon(s.ic, s.c)}
      <span class="txt"><b>${s.n}${s.hit ? '<span class="hit">хит</span>' : ''}</b><small>${s.note}</small></span>
      <span class="end"><b>${s.old ? `<s style="color:var(--hint);font-weight:400;font-size:13px">${nf.format(s.old)}</s> ` : ''}${rub(s.p)}</b><small>${s.d} мин</small></span></button>`).join('')
  }</div>`).join('') + '<p class="caption">Цена указана для барбера. У топ-барбера +20%, у младшего −15%.</p>';
  const svc = SVC.find(s => s.id === S.service);
  UI.main(svc ? `Выбрать мастера · ${svc.n.toLowerCase()}` : 'Выберите услугу', !!svc, () => { UI.tick(); go('master'); });
}
$('#services').addEventListener('click', e => {
  const b = e.target.closest('[data-svc]'); if (!b) return;
  S.service = b.dataset.svc; S.date = null; S.cell = null;
  UI.tick(); renderHome();
});
$$('.tabs button').forEach(b => b.addEventListener('click', () => { tab = b.dataset.tab; UI.tick(); renderHome(); }));

/* ---------- 2. мастер ---------- */
function renderMasters() {
  const svc = SVC.find(s => s.id === S.service), cells = cellsOf(svc);
  $('#masterSub').textContent = `${svc.n}, ${svc.d} мин`;
  const anyN = nearest(null, cells);
  const rows = [`<button class="item ma" role="radio" aria-checked="${S.master === 'any'}" data-m="any">${icon('any', '#8E8E93').replace('class="ico"', 'class="ava"')}
      <span class="txt"><b>Любой мастер</b><small>Ближайшее окно: <span>${nearestText(anyN)}</span></small></span><span class="end"><b>от ${rub(priceFor(svc, MASTERS[3]))}</b></span></button>`];
  MASTERS.forEach(m => {
    const n = nearest(m.id, cells);
    rows.push(`<button class="item ma ${n ? '' : 'off'}" role="radio" aria-checked="${S.master === m.id}" data-m="${m.id}" ${n ? '' : 'disabled'}>
      <span class="ava" style="background:${m.c}">${m.n.split(' ').map(x => x[0]).join('')}</span>
      <span class="txt"><b>${m.n}</b><small>${m.rank} · ★ ${m.rating} (${m.reviews})</small><small>Ближайшее: <span>${nearestText(n)}</span></small></span>
      <span class="end"><b>${rub(priceFor(svc, m))}</b></span></button>`);
  });
  $('#masters').innerHTML = rows.join('');
  const chosen = S.master && (S.master === 'any' ? 'любой мастер' : MS(S.master).short);
  UI.main(chosen ? `Выбрать время · ${chosen}` : 'Выберите мастера', !!chosen, () => { UI.tick(); go('time'); });
}
$('#masters').addEventListener('click', e => {
  const b = e.target.closest('[data-m]'); if (!b || b.disabled) return;
  S.master = b.dataset.m; S.date = null; S.cell = null;
  UI.tick(); renderMasters();
});

/* ---------- 3. дата и время ---------- */
function renderTime() {
  const svc = SVC.find(s => s.id === S.service), cells = cellsOf(svc);
  const only = S.master === 'any' ? null : S.master;
  $('#timeSub').textContent = `${only ? MS(only).n : 'Любой мастер'}, ${svc.d} мин`;
  const dayHas = key => { for (let c = 0; c < CELLS; c++) if (freeMasters(key, c, cells, only).length) return true; return false; };
  if (!S.date) { const n = nearest(only, cells); S.date = n ? n.key : keyOf(DAYS[0]); }
  $('#dates').innerHTML = DAYS.map((d, i) => {
    const key = keyOf(d), off = only && d.getDay() === MS(only).off, has = !off && dayHas(key);
    return `<button class="date" role="option" aria-selected="${S.date === key}" data-d="${key}" ${has ? '' : 'disabled'}><small>${dayLabel(d, i)}</small><b>${d.getDate()}</b><em>${off ? 'выходной' : MON_S[d.getMonth()]}</em></button>`;
  }).join('');
  const groups = [['Утро', 0, 4], ['День', 4, 14], ['Вечер', 14, CELLS]];
  let any = false;
  const html = groups.map(([t, a, b]) => {
    const btns = [];
    for (let c = a; c < b; c++) {
      if (c + cells > CELLS) continue;
      const free = freeMasters(S.date, c, cells, only).length > 0;
      if (free) any = true;
      btns.push(`<button class="slot" data-c="${c}" aria-pressed="${S.cell === c}" ${free ? '' : 'disabled'} aria-label="${cellTime(c)}${free ? '' : ', занято'}">${cellTime(c)}</button>`);
    }
    return btns.length ? `<div class="slot-group"><h3>${t}</h3><div class="slots">${btns.join('')}</div></div>` : '';
  }).join('');
  $('#slots').innerHTML = any ? html : `<div class="empty"><b>На этот день всё занято</b>Попробуйте другую дату или любого мастера.<br><button id="jumpFree">Показать ближайший свободный день</button></div>`;
  const jb = $('#jumpFree');
  if (jb) jb.addEventListener('click', () => { const n = nearest(only, cells); if (n) { S.date = n.key; S.cell = null; renderTime(); } });
  const sel = $('.date[aria-selected="true"]');
  if (sel) sel.scrollIntoView({block: 'nearest', inline: 'center'});
  if (S.cell !== null) {
    const d = fromKey(S.date);
    UI.main(`Далее · ${d.getDate()} ${MON_S[d.getMonth()]}, ${cellTime(S.cell)}`, true, () => { UI.tick(); go('confirm'); });
  } else UI.main('Выберите время', false, () => {});
}
$('#dates').addEventListener('click', e => {
  const b = e.target.closest('[data-d]'); if (!b || b.disabled) return;
  S.date = b.dataset.d; S.cell = null; UI.tick(); renderTime();
});
$('#slots').addEventListener('click', e => {
  const b = e.target.closest('[data-c]'); if (!b || b.disabled) return;
  S.cell = +b.dataset.c; UI.tick(); renderTime();
});

/* ---------- 4. подтверждение ---------- */
function resolveMaster() {
  const svc = SVC.find(s => s.id === S.service);
  if (S.master !== 'any') return MS(S.master);
  // любой мастер: берём свободного с лучшей ценой для клиента
  return freeMasters(S.date, S.cell, cellsOf(svc)).sort((a, b) => a.k - b.k)[0];
}
function whenText(key, cell, cells, full) {
  const d = fromKey(key);
  const day = full ? `${WD_FULL[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()]}` : `${WD[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()]}`;
  return `${day}, ${cellTime(cell)}–${cellTime(cell + cells)}`;
}
function summaryHTML(b) {
  return `<div class="srow"><span>Услуга</span><b>${esc(b.service)}</b></div>
    <div class="srow"><span>Мастер</span><b>${esc(b.master)}</b></div>
    <div class="srow"><span>Когда</span><b>${whenText(b.date, b.cell, b.cells)}</b></div>
    <div class="srow"><span>Адрес</span><b>Красный проспект, 77</b></div>
    <div class="srow total"><span>К оплате</span><b>${rub(b.price)}</b></div>`;
}
function draft() {
  const svc = SVC.find(s => s.id === S.service), m = resolveMaster();
  return {service: svc.n, serviceId: svc.id, master: m.n, masterId: m.id, date: S.date, cell: S.cell, cells: cellsOf(svc), price: priceFor(svc, m)};
}
const fName = $('#fName'), fPhone = $('#fPhone');
function renderConfirm() {
  const b = draft();
  $('#summary').innerHTML = summaryHTML(b) + (S.master === 'any' ? `<div class="srow"><span></span><b style="color:var(--hint);font-weight:400;font-size:13px">Свободен ${esc(MS(b.masterId).short)} — назначили его</b></div>` : '');
  const u = inTG && tg.initDataUnsafe && tg.initDataUnsafe.user;
  const prev = bookings[bookings.length - 1];  // постоянному клиенту не нужно вводить контакты заново
  if (!fName.value) fName.value = prev ? prev.name : u ? [u.first_name, u.last_name].filter(Boolean).join(' ') : '';
  if (!fPhone.value && prev) fPhone.value = prev.phone;
  $('#sharePhone').hidden = !ver('6.9');
  $('#formErr').textContent = '';
  UI.main(`${S.rescheduling ? 'Перенести запись' : 'Записаться'} · ${rub(b.price)}`, true, submit);
}
[fName, fPhone].forEach(i => i.addEventListener('input', () => { $('#formErr').textContent = ''; }));
fPhone.addEventListener('input', () => {
  let d = fPhone.value.replace(/\D/g, '');
  if (!d) { fPhone.value = ''; return; }
  if (d[0] === '8') d = '7' + d.slice(1);
  if (d[0] !== '7') d = '7' + d;
  d = d.slice(0, 11);
  const p = [d.slice(1, 4), d.slice(4, 7), d.slice(7, 9), d.slice(9, 11)];
  fPhone.value = '+7' + (p[0] ? ' ' + p[0] : '') + (p[1] ? ' ' + p[1] : '') + (p[2] ? '-' + p[2] : '') + (p[3] ? '-' + p[3] : '');
});
$('#sharePhone').addEventListener('click', () => {
  tg.requestContact((ok, res) => {
    const ph = ok && res && res.responseUnsafe && res.responseUnsafe.contact && res.responseUnsafe.contact.phone_number;
    if (ph) { fPhone.value = ph.startsWith('+') ? ph : '+' + ph; fPhone.dispatchEvent(new Event('input')); UI.buzz('success'); }
  });
});

async function submit() {
  const name = fName.value.trim(), digits = fPhone.value.replace(/\D/g, '');
  const errs = [];
  if (!name) errs.push('укажите имя');
  if (digits.length !== 11) errs.push('введите телефон полностью: +7 и 10 цифр');
  if (errs.length) {
    $('#formErr').textContent = errs.join(', ').replace(/^./, c => c.toUpperCase()) + '.';
    UI.buzz('error'); (name ? fPhone : fName).focus(); return;
  }
  // слот могли занять, пока клиент заполнял форму
  const svc = SVC.find(s => s.id === S.service);
  if (!freeMasters(S.date, S.cell, cellsOf(svc), S.master === 'any' ? null : S.master).length) {
    UI.buzz('warning'); toast('Это время только что заняли. Выберите другое.'); S.cell = null; go('time', true); return;
  }
  const b = {...draft(), id: Date.now().toString(36), name, phone: fPhone.value, note: $('#fNote').value.trim(), remind: $('#fRemind').checked, created: new Date().toISOString()};
  UI.progress(true);
  let mode = 'demo';
  try {
    if (CONFIG.apiUrl && inTG) {
      const r = await fetch(CONFIG.apiUrl, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({initData: tg.initData, booking: b})});
      if (!r.ok) throw new Error(r.status);
      mode = 'api';
    } else await new Promise(r => setTimeout(r, 650));
  } catch (e) {
    UI.progress(false); UI.buzz('error');
    $('#formErr').textContent = 'Не получилось отправить запись. Проверьте интернет и попробуйте ещё раз или позвоните: +7 383 312-44-90.';
    return;
  }
  if (S.rescheduling) bookings = bookings.filter(x => x.id !== S.rescheduling);
  bookings.push(b); store.save(bookings);
  UI.progress(false); UI.buzz('success');
  // приложение открыто кнопкой клавиатуры бота — отдаём запись боту, Telegram сам закроет окно
  // приложение открыто кнопкой клавиатуры бота — передаём запись боту (Telegram закроет окно сам)
  if (inTG && mode === 'demo' && !(tg.initDataUnsafe && tg.initDataUnsafe.query_id)) {
    try { tg.sendData(JSON.stringify(b)); mode = 'bot'; } catch (e) { /* открыто не с клавиатуры — остаёмся в демо */ }
  }
  showDone(b, mode);
}

/* ---------- 5. готово ---------- */
let lastBooking = null;
function showDone(b, mode) {
  lastBooking = b;
  const d = fromKey(b.date), m = MS(b.masterId);
  $('#doneText').textContent = `Ждём вас в ${WD_FULL[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()]}, в ${cellTime(b.cell)}. Мастер — ${m.short}.`;
  $('#doneSummary').innerHTML = summaryHTML(b);
  $('#doneNote').textContent = mode === 'api' || mode === 'bot'
    ? (b.remind ? 'Бот пришлёт подтверждение в чат и напомнит за 2 часа до визита.' : 'Бот пришлёт подтверждение в чат.')
    : 'Демо-режим: запись сохранена только на этом устройстве. В рабочей версии бот пришлёт подтверждение, а администратор увидит запись в своём чате.';
  S.rescheduling = null;
  go('done');
  UI.main('Готово', true, () => {
    if (inTG) return tg.close();
    S.service = S.master = S.date = null; S.cell = null; tab = 'mine'; go('home', true);
  });
}
$('#addCal').addEventListener('click', () => {
  const b = lastBooking; if (!b) return;
  const d = fromKey(b.date);
  const pad = n => String(n).padStart(2, '0');
  const t = c => `${OPEN + Math.floor(c / 2)}${c % 2 ? '30' : '00'}`.padStart(4, '0');
  const ymd = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
  const title = `Бритва: ${b.service}`, place = 'Новосибирск, Красный проспект, 77', details = `Мастер: ${b.master}. Отменить: t.me/britva_nsk_bot`;
  if (inTG) {
    const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${ymd}T${t(b.cell)}00/${ymd}T${t(b.cell + b.cells)}00&ctz=${TZ}&location=${encodeURIComponent(place)}&details=${encodeURIComponent(details)}`;
    return UI.open(url);
  }
  const ics = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Britva//RU', 'BEGIN:VEVENT', `UID:${b.id}@britva`,
    `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').slice(0, 15)}Z`,
    `DTSTART;TZID=${TZ}:${ymd}T${t(b.cell)}00`, `DTEND;TZID=${TZ}:${ymd}T${t(b.cell + b.cells)}00`,
    `SUMMARY:${title}`, `LOCATION:${place}`, `DESCRIPTION:${details}`,
    'BEGIN:VALARM', 'TRIGGER:-PT2H', 'ACTION:DISPLAY', 'DESCRIPTION:Скоро стрижка', 'END:VALARM', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([ics], {type: 'text/calendar'}));
  a.download = 'britva.ics'; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  toast('Файл для календаря скачан');
});
$('#route').addEventListener('click', () => UI.open('https://yandex.ru/maps/?text=' + encodeURIComponent('Новосибирск, Красный проспект, 77')));

/* ---------- мои записи ---------- */
function upcomingBookings() {
  const now = salonNow(), today = keyOf(now), nowCell = (now.getHours() - OPEN) * 2 + (now.getMinutes() >= 30 ? 1 : 0);
  return bookings.filter(b => b.date > today || (b.date === today && b.cell >= nowCell)).sort((a, b) => (a.date + String(a.cell).padStart(2, '0')).localeCompare(b.date + String(b.cell).padStart(2, '0')));
}
function renderMine(list) {
  $('#tabMine').innerHTML = list.length ? `<div class="section" style="margin-top:12px">${list.map(b => `
    <div class="booking"><div class="when">${whenText(b.date, b.cell, b.cells)}</div>
    <div class="what">${esc(b.service)} · ${esc(MS(b.masterId).short)} · ${rub(b.price)}</div>
    <div class="acts"><button data-move="${b.id}">Перенести</button><button class="cancel" data-cancel="${b.id}">Отменить</button></div></div>`).join('')}</div>
    <p class="caption">Отменить или перенести можно бесплатно за 3 часа до визита.</p>`
    : `<div class="empty" style="margin-top:12px"><b>Записей пока нет</b>Выберите услугу — это займёт полминуты.<br><button id="toBook">Записаться</button></div>`;
  const tb = $('#toBook'); if (tb) tb.addEventListener('click', () => { tab = 'book'; renderHome(); });
}
$('#tabMine').addEventListener('click', e => {
  const c = e.target.closest('[data-cancel]'), mv = e.target.closest('[data-move]');
  if (c) UI.confirm('Отменить запись? Время освободится для других.', ok => {
    if (!ok) return;
    bookings = bookings.filter(b => b.id !== c.dataset.cancel); store.save(bookings);
    UI.buzz('success'); toast('Запись отменена'); renderHome();
  });
  if (mv) {
    const b = bookings.find(x => x.id === mv.dataset.move);
    Object.assign(S, {service: b.serviceId, master: b.masterId, date: b.date, cell: null, rescheduling: b.id});
    tab = 'book'; go('time');
  }
});

/* ---------- мелочи ---------- */
let toastT;
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('on'), 2400); }
(() => {
  const now = salonNow(), h = now.getHours() + now.getMinutes() / 60, el = $('#openNow');
  const open = h >= OPEN && h < CLOSE;
  el.textContent = open ? `Открыто до ${CLOSE}:00` : `Закрыто, откроемся в ${OPEN}:00`;
  el.classList.toggle('closed', !open);
})();

store.load(list => { bookings = Array.isArray(list) ? list : []; go('home'); });
})();
