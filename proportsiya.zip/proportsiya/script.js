/* Пропорция — логика страницы */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const nf = new Intl.NumberFormat('ru-RU');
const rub = n => nf.format(Math.round(n)) + ' ₽';
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c; };

/* меню */
const burger = $('#burger');
const setNav = open => { document.body.classList.toggle('nav-open', open); burger.setAttribute('aria-expanded', open); burger.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню'); };
burger.addEventListener('click', () => setNav(!document.body.classList.contains('nav-open')));
$$('#mnav a').forEach(a => a.addEventListener('click', () => setNav(false)));
addEventListener('keydown', e => e.key === 'Escape' && setNav(false));

/* проекты */
const PAL = {
  arbat:  {wall: '#EDE8E1', floor: '#C9A887', main: '#7D8F7A', accent: '#D9B38C', rug: '#E3DDD3', wood: '#9C7654', art1: '#C98F6B', art2: '#8FA3A0'},
  zhav:   {wall: '#E7E9E8', floor: '#B59578', main: '#3F4A5A', accent: '#C58F5E', rug: '#DAD6CF', wood: '#7A5B42', art1: '#D8C3A5', art2: '#6F8A9A'},
  sokol:  {wall: '#F1EDE6', floor: '#D9CCBB', main: '#C9B7A2', accent: '#5D6B58', rug: '#E9E3D9', wood: '#A88C6C', art1: '#5D6B58', art2: '#C9B7A2'},
  symbol: {wall: '#DDE3DE', floor: '#BFA27F', main: '#C9B7A2', accent: '#9A6B52', rug: '#F1EDE6', wood: '#9C7654', art2: '#7E958C'},
  vektor: {wall: '#EAE6DF', floor: '#8C6F55', main: '#2E3A3B', accent: '#C58F5E', rug: '#D9D2C6', wood: '#B08B66', art1: '#C58F5E', art2: '#8FA3A0'},
  istra:  {wall: '#EFE7DC', floor: '#9E7B5A', main: '#8C6A58', accent: '#3E5B53', rug: '#F4EFE8', wood: '#6E4F39', art2: '#A3B1A6'},
};
const PROJECTS = [
  {id: 'arbat', cat: 'flat', kind: 'living', title: 'Квартира на Арбате', place: 'Москва, ЦАО', area: 78, style: 'Современная классика', weeks: 8, budget: '6,2 млн ₽',
    task: 'Семья с подростком переезжала из трёшки в старом фонде. Нужно было уместить три спальни, кабинет и не потерять высоту потолков 3,4 м.',
    done: 'Перенесли кухню в бывшую кладовую, спрятали инженерию в подиум и получили гардероб 6 м². Сохранили исторический паркет — его отреставрировали.'},
  {id: 'zhav', cat: 'house', kind: 'living', title: 'Дом в Жаворонках', place: 'Одинцовский округ', area: 186, style: 'Тёплый минимализм', weeks: 12, budget: '14,8 млн ₽',
    task: 'Дом из клеёного бруса для семьи с двумя детьми и собакой. Хозяева хотели много света и чтобы в прихожей было куда деть грязные сапоги.',
    done: 'Сделали сквозную гостиную с кухней и выходом на террасу, отдельную «грязную» прихожую с душем для собаки и детскую с антресолью для игр.'},
  {id: 'sokol', cat: 'flat', kind: 'living', title: 'Студия на Соколе', place: 'Москва, САО', area: 36, style: 'Джапанди', weeks: 6, budget: '2,4 млн ₽',
    task: 'Студия для сдачи в аренду на длинный срок. Бюджет ограничен, материалы должны пережить нескольких жильцов.',
    done: 'Кварцвинил вместо ламината, моющаяся краска, встроенные шкафы до потолка. Квартиру сдали через четыре дня после съёмки.'},
  {id: 'symbol', cat: 'flat', kind: 'bedroom', title: 'Квартира в ЖК «Символ»', place: 'Москва, ЮВАО', area: 64, style: 'Скандинавский', weeks: 7, budget: '4,1 млн ₽',
    task: 'Молодая пара ждала ребёнка. В двушке нужно было выделить детскую, не лишая родителей спальни.',
    done: 'Объединили гостиную с кухней, из маленькой комнаты сделали детскую, а в спальне спроектировали нишу под кровать и тихий гардероб.'},
  {id: 'vektor', cat: 'office', kind: 'office', title: 'Юридическое бюро «Вектор»', place: 'Москва, Пресненская набережная', area: 120, style: 'Строгий современный', weeks: 7, budget: '9,5 млн ₽',
    task: 'Офис на 14 сотрудников и переговорные для клиентов. Ремонт нужно было провести без остановки работы.',
    done: 'Разбили работы на три очереди по кабинетам, сделали акустические перегородки и переговорную, которую не стыдно показать крупному клиенту.'},
  {id: 'istra', cat: 'house', kind: 'bedroom', title: 'Дом в Истре', place: 'Истринский округ', area: 240, style: 'Шале', weeks: 14, budget: '18,3 млн ₽',
    task: 'Загородный дом для большой семьи, где собираются по выходным. Хотелось уюта горного отеля, но без тяжёлой «охотничьей» эстетики.',
    done: 'Светлая древесина, камень у камина, шесть спален с собственными ванными. Мебель заказали у трёх российских фабрик — всё пришло за 9 недель.'},
];
const grid = $('#projectsGrid');
grid.innerHTML = PROJECTS.map(p => `<button class="proj" data-cat="${p.cat}" data-id="${p.id}" aria-haspopup="dialog">
  <div class="proj__img">${roomSVG({...PAL[p.id], kind: p.kind})}</div>
  <div class="proj__meta"><h3>${p.title}</h3><span>${p.area} м²</span></div>
  <p class="proj__style">${p.style}, ${p.place}</p></button>`).join('');
$$('.filters .chip').forEach(c => {
  const f = c.dataset.f;
  $('small', c).textContent = f === 'all' ? PROJECTS.length : PROJECTS.filter(p => p.cat === f).length;
  c.addEventListener('click', () => {
    $$('.filters .chip').forEach(x => x.setAttribute('aria-pressed', x === c));
    $$('.proj', grid).forEach(el => { el.hidden = f !== 'all' && el.dataset.cat !== f; });
  });
});

const modal = $('#modal');
grid.addEventListener('click', e => {
  const card = e.target.closest('.proj'); if (!card) return;
  const p = PROJECTS.find(x => x.id === card.dataset.id);
  $('#mImg').innerHTML = roomSVG({...PAL[p.id], kind: p.kind});
  $('#mImg').style.background = `linear-gradient(${PAL[p.id].wall} 50%, ${PAL[p.id].floor} 50%)`;
  $('#mPlace').textContent = p.place;
  $('#mTitle').textContent = p.title;
  $('#mFacts').innerHTML = [['Площадь', p.area + ' м²'], ['Стиль', p.style], ['Проект', p.weeks + ' ' + plural(p.weeks, 'неделя', 'недели', 'недель')], ['Бюджет ремонта', p.budget]]
    .map(([a, b]) => `<div><span>${a}</span><b>${b}</b></div>`).join('');
  $('#mTask').textContent = p.task;
  $('#mDone').textContent = p.done;
  $('#mCta').dataset.ref = p.title;
  modal.showModal();
});
$('#mClose').addEventListener('click', () => modal.close());
modal.addEventListener('click', e => { if (e.target === modal) modal.close(); });
$('#mCta').addEventListener('click', e => {
  modal.close();
  $('#fMsg').value = `Хочу похожий проект, как «${e.currentTarget.dataset.ref}»`;
});

/* до / после */
$('#baAfter').innerHTML = roomSVG({...PAL.arbat, kind: 'living'});
$('#baBefore').innerHTML = roomSVG({state: 'before'});
const ba = $('#ba'), baRange = $('#baRange');
const setPos = v => { v = Math.max(0, Math.min(100, v)); ba.style.setProperty('--pos', v + '%'); baRange.value = Math.round(v); };
baRange.addEventListener('input', () => setPos(+baRange.value));
let dragging = false;
const fromEvent = e => { const r = ba.getBoundingClientRect(); setPos((e.clientX - r.left) / r.width * 100); };
ba.addEventListener('pointerdown', e => {
  dragging = true; ba.classList.add('dragging');
  ba.setPointerCapture(e.pointerId); fromEvent(e); e.preventDefault();
});
ba.addEventListener('pointermove', e => { if (dragging) fromEvent(e); });
const stop = e => { dragging = false; ba.classList.remove('dragging'); if (ba.hasPointerCapture?.(e.pointerId)) ba.releasePointerCapture(e.pointerId); };
ba.addEventListener('pointerup', stop);
ba.addEventListener('pointercancel', stop);

/* калькулятор */
const PRICE = {plan: 1500, design: 3800};
const K = {flat: 1, house: 1.15, office: 1.1};
const areaR = $('#areaRange'), areaN = $('#area');
const setFill = () => areaR.style.setProperty('--p', ((areaR.value - areaR.min) / (areaR.max - areaR.min) * 100) + '%');
function calc() {
  const area = Math.min(500, Math.max(20, +areaN.value || 20));
  const obj = $('input[name=obj]:checked').value, pack = $('input[name=pack]:checked').value;
  const sup = $('#optSup').checked, kit = $('#optKit').checked;
  const k = K[obj];
  const months = Math.min(10, Math.max(3, Math.ceil(area / 30) + (obj === 'house' ? 2 : 1)));
  $('#supMonths').textContent = `≈ ${months} мес. × 45 000 ₽`;
  const base = area * PRICE[pack] * k;
  const rows = [[pack === 'plan' ? 'Планировка' : 'Дизайн-проект', base]];
  if (sup) rows.push([`Надзор, ${months} мес.`, months * 45000]);
  if (kit) rows.push(['Комплектация', area * 900]);
  const total = rows.reduce((s, r) => s + r[1], 0);
  const weeks = pack === 'plan' ? Math.round(2 + area / 80) : Math.round(5 + area / 40 + (obj === 'house' ? 1 : 0));
  $('#total').textContent = rub(total);
  $('#perM').textContent = `${rub(total / area)} за м² с учётом выбранного`;
  $('#lines').innerHTML = rows.map(([n, v]) => `<li><span>${n}</span><b>${rub(v)}</b></li>`).join('') +
    `<li><span>Срок проекта</span><b>${weeks} ${plural(weeks, 'неделя', 'недели', 'недель')}</b></li>`;
  $('#calcCta').dataset.summary = `${obj === 'flat' ? 'Квартира' : obj === 'house' ? 'Дом' : 'Коммерческое помещение'} ${area} м², ${pack === 'plan' ? 'планировка' : 'дизайн-проект'}${sup ? ', надзор' : ''}${kit ? ', комплектация' : ''}. Расчёт на сайте: ${rub(total)}`;
}
areaR.addEventListener('input', () => { areaN.value = areaR.value; setFill(); calc(); });
areaN.addEventListener('input', () => { const v = +areaN.value; if (v >= 20) { areaR.value = Math.min(300, v); setFill(); calc(); } });
areaN.addEventListener('change', () => { areaN.value = Math.min(500, Math.max(20, +areaN.value || 20)); areaR.value = Math.min(300, areaN.value); setFill(); calc(); });
$$('.calc input[type=radio], .calc input[type=checkbox]').forEach(i => i.addEventListener('change', calc));
$('#calcCta').addEventListener('click', e => { $('#fMsg').value = e.currentTarget.dataset.summary; });
setFill(); calc();

/* форма */
const form = $('#form'), phone = $('#fPhone'), nameI = $('#fName');
phone.addEventListener('input', () => {
  let d = phone.value.replace(/\D/g, '');
  if (!d) { phone.value = ''; return; }
  if (d[0] === '8') d = '7' + d.slice(1);
  if (d[0] !== '7') d = '7' + d;
  d = d.slice(0, 11);
  const p = [d.slice(1, 4), d.slice(4, 7), d.slice(7, 9), d.slice(9, 11)];
  phone.value = '+7' + (p[0] ? ' ' + p[0] : '') + (p[1] ? ' ' + p[1] : '') + (p[2] ? '-' + p[2] : '') + (p[3] ? '-' + p[3] : '');
});
const err = (k, m) => { const f = $(`[data-f="${k}"]`, form); f.classList.toggle('err', !!m); $('.msg', f).textContent = m || ''; return !m; };
nameI.addEventListener('input', () => err('name', ''));
phone.addEventListener('input', () => err('phone', ''));
form.addEventListener('submit', e => {
  e.preventDefault();
  const a = err('name', nameI.value.trim() ? '' : 'Напишите, как к вам обращаться');
  const b = err('phone', phone.value.replace(/\D/g, '').length === 11 ? '' : 'Нужен номер целиком: +7 и 10 цифр');
  if (!a || !b) { $('.err input', form).focus(); return; }
  const via = $('input[name=via]:checked').value;
  $('#doneTitle').textContent = `Спасибо, ${nameI.value.trim().split(' ')[0]}`;
  $('#doneText').textContent = via === 'Звонок'
    ? `Дизайнер позвонит на ${phone.value} в течение рабочего дня.`
    : `Дизайнер напишет в ${via} на ${phone.value} в течение рабочего дня.`;
  form.classList.add('sent');
});
})();
