/* Иллюстрации интерьеров: одна функция рисует комнату «до» или «после» в нужной палитре */
window.roomSVG = function (o) {
  const p = Object.assign({
    wall: '#EDE8E1', floor: '#C9A887', main: '#7D8F7A', accent: '#D9B38C', rug: '#E3DDD3',
    wood: '#9C7654', dark: '#2B2F33', art1: '#C98F6B', art2: '#8FA3A0', kind: 'living', state: 'after'
  }, o);
  const s = [];
  const add = x => s.push(x);
  const before = p.state === 'before';
  const wall = before ? '#CFCBC4' : p.wall, floor = before ? '#B8B3AA' : p.floor;

  // стена, пол, плинтус
  add(`<rect width="480" height="252" fill="${wall}"/>`);
  add(`<rect y="252" width="480" height="108" fill="${floor}"/>`);
  if (!before) {
    for (const y of [270, 292, 320]) add(`<line x1="0" x2="480" y1="${y}" y2="${y}" stroke="#000" stroke-opacity=".06"/>`);
    for (const [x, y1, y2] of [[60, 252, 270], [190, 270, 292], [330, 252, 270], [110, 292, 320], [400, 292, 320], [250, 320, 360]])
      add(`<line x1="${x}" x2="${x}" y1="${y1}" y2="${y2}" stroke="#000" stroke-opacity=".06"/>`);
    add(`<rect y="246" width="480" height="6" fill="#fff" fill-opacity=".55"/>`);
  } else {
    for (const [x, y, r] of [[60, 60, 40], [180, 150, 55], [400, 210, 36], [260, 40, 30], [110, 300, 50], [360, 330, 44]])
      add(`<circle cx="${x}" cy="${y}" r="${r}" fill="#000" fill-opacity=".035"/>`);
    add(`<path d="M0 252h480" stroke="#000" stroke-opacity=".12"/>`);
  }
  // окно и свет
  add(`<rect x="318" y="46" width="118" height="156" fill="${before ? '#DDE1E1' : '#EEF3F3'}" stroke="${before ? '#9C9892' : '#fff'}" stroke-width="6"/>`);
  add(`<path d="M377 46v156M318 124h118" stroke="${before ? '#9C9892' : '#fff'}" stroke-width="4"/>`);
  if (before) add(`<path d="M326 54l102 140M428 54L326 194" stroke="#D6C28B" stroke-width="5" stroke-opacity=".8"/>`);
  add(`<path d="M318 252h118l40 108H300z" fill="#fff" fill-opacity="${before ? .12 : .22}"/>`);

  if (before) {
    // лампочка, стремянка, вёдра, мешок, кабели
    add(`<path d="M150 0v96" stroke="#3a3a3a" stroke-width="2"/><circle cx="150" cy="104" r="9" fill="#F4E7B5"/><rect x="146" y="92" width="8" height="6" fill="#555"/>`);
    add(`<g stroke="#8C8578" stroke-width="5" stroke-linecap="round"><path d="M200 330l34-170M268 330l-34-170"/><path d="M212 272h44M220 232h28M227 196h14"/></g>`);
    add(`<rect x="78" y="296" width="44" height="46" rx="4" fill="#E9E6DF" stroke="#8C8578" stroke-width="2"/><rect x="78" y="296" width="44" height="10" fill="#6E9BB3"/>`);
    add(`<rect x="126" y="310" width="36" height="34" rx="4" fill="#E9E6DF" stroke="#8C8578" stroke-width="2"/>`);
    add(`<path d="M300 346c-4-30 6-44 34-46h40c26 2 34 18 30 46z" fill="#D8CDB8" stroke="#A79C86" stroke-width="2"/><path d="M330 318h44" stroke="#A79C86" stroke-width="3"/>`);
    add(`<path d="M20 120c20 10 10 60 40 70s40-20 60 0" fill="none" stroke="#6b6b6b" stroke-width="2"/>`);
    add(`<rect x="20" y="170" width="22" height="30" rx="2" fill="none" stroke="#6b6b6b" stroke-width="2"/>`);
    return `<svg viewBox="0 0 480 360" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">${s.join('')}</svg>`;
  }

  if (p.kind === 'living') {
    add(`<ellipse cx="200" cy="322" rx="170" ry="28" fill="${p.rug}"/>`);
    // картины
    add(`<rect x="112" y="72" width="64" height="84" fill="#fff"/><rect x="118" y="78" width="52" height="72" fill="${p.art1}" fill-opacity=".85"/><circle cx="144" cy="104" r="14" fill="#fff" fill-opacity=".5"/>`);
    add(`<rect x="188" y="92" width="80" height="56" fill="#fff"/><rect x="194" y="98" width="68" height="44" fill="${p.art2}"/><path d="M194 132l22-18 18 12 28-20v36h-68z" fill="#fff" fill-opacity=".35"/>`);
    // диван
    add(`<rect x="72" y="178" width="228" height="58" rx="16" fill="${p.main}"/>`);
    add(`<rect x="62" y="220" width="248" height="44" rx="14" fill="${p.main}"/><rect x="62" y="220" width="248" height="44" rx="14" fill="#fff" fill-opacity=".08"/>`);
    add(`<rect x="50" y="196" width="36" height="70" rx="14" fill="${p.main}"/><rect x="286" y="196" width="36" height="70" rx="14" fill="${p.main}"/>`);
    add(`<rect x="50" y="196" width="36" height="70" rx="14" fill="#000" fill-opacity=".08"/><rect x="286" y="196" width="36" height="70" rx="14" fill="#000" fill-opacity=".08"/>`);
    add(`<rect x="96" y="194" width="52" height="38" rx="10" fill="${p.accent}" transform="rotate(-6 122 213)"/><rect x="226" y="196" width="48" height="36" rx="10" fill="#fff" fill-opacity=".75" transform="rotate(5 250 214)"/>`);
    add(`<path d="M70 266v10M302 266v10" stroke="${p.dark}" stroke-width="4"/>`);
    // столик
    add(`<path d="M200 306v26M260 306v26M230 306v30" stroke="${p.wood}" stroke-width="3"/><ellipse cx="230" cy="304" rx="58" ry="10" fill="${p.wood}"/><ellipse cx="230" cy="301" rx="58" ry="9" fill="${p.wood}"/><ellipse cx="230" cy="301" rx="58" ry="9" fill="#fff" fill-opacity=".15"/>`);
    add(`<rect x="208" y="286" width="16" height="14" rx="2" fill="#fff"/><path d="M246 296c0-12 16-12 16 0z" fill="${p.accent}"/>`);
    // торшер
    add(`<path d="M26 330V118" stroke="${p.dark}" stroke-width="3"/><ellipse cx="26" cy="332" rx="16" ry="4" fill="${p.dark}"/><path d="M8 118h36l-8-30H16z" fill="#F7F1E3" stroke="${p.dark}" stroke-opacity=".2"/>`);
  }

  if (p.kind === 'bedroom') {
    add(`<rect x="60" y="40" width="4" height="60" fill="${p.dark}"/><path d="M40 100h44l-8 22H48z" fill="${p.accent}"/>`);
    
    add(`<rect x="120" y="120" width="190" height="110" rx="10" fill="${p.main}"/>`);
    add(`<rect x="130" y="180" width="80" height="34" rx="10" fill="#fff"/><rect x="218" y="180" width="80" height="34" rx="10" fill="#fff"/><rect x="170" y="190" width="70" height="28" rx="9" fill="${p.accent}"/>`);
    add(`<path d="M100 226h230v56a8 8 0 0 1-8 8H108a8 8 0 0 1-8-8z" fill="${p.rug}"/>`);
    add(`<path d="M100 226h230v24H100z" fill="#fff" fill-opacity=".85"/>`);
    add(`<path d="M200 250c30 8 70 6 130-4v36a8 8 0 0 1-8 8H206z" fill="${p.accent}" fill-opacity=".55"/>`);
    add(`<rect x="22" y="228" width="56" height="54" rx="4" fill="${p.wood}"/><path d="M22 255h56" stroke="#000" stroke-opacity=".15"/><rect x="36" y="206" width="26" height="22" rx="3" fill="#fff"/>`);
    add(`<rect x="344" y="228" width="56" height="54" rx="4" fill="${p.wood}"/><path d="M344 255h56" stroke="#000" stroke-opacity=".15"/>`);
    add(`<path d="M360 228c0-20 6-28 12-28s12 8 12 28z" fill="${p.art2}"/>`);
  }

  if (p.kind === 'office') {
    // стеллаж
    add(`<rect x="24" y="60" width="130" height="190" fill="${p.wood}"/>`);
    for (const y of [100, 145, 190]) add(`<rect x="24" y="${y}" width="130" height="5" fill="#000" fill-opacity=".15"/>`);
    const books = [[34, 70, 12, p.accent], [48, 76, 10, p.art2], [60, 66, 14, '#fff'], [78, 74, 10, p.main], [100, 112, 12, p.art1], [114, 118, 10, '#fff'], [128, 108, 14, p.accent], [36, 160, 12, p.main], [52, 156, 12, '#fff'], [92, 206, 30, p.art2]];
    books.forEach(([x, y, w, c]) => add(`<rect x="${x}" y="${y}" width="${w}" height="${y > 200 ? 38 : (y > 150 ? 29 : 30)}" fill="${c}"/>`));
    add(`<path d="M120 172c0-10 16-10 16 0v18h-16z" fill="${p.art1}"/>`);
    // стол
    add(`<rect x="180" y="206" width="210" height="10" rx="2" fill="${p.wood}"/><path d="M190 216v74M380 216v74" stroke="${p.dark}" stroke-width="4"/>`);
    add(`<rect x="250" y="150" width="80" height="52" rx="4" fill="${p.dark}"/><rect x="254" y="154" width="72" height="42" fill="${p.art2}" fill-opacity=".6"/><path d="M290 202v4" stroke="${p.dark}" stroke-width="4"/>`);
    add(`<path d="M206 206c0-18 6-26 14-26" stroke="${p.dark}" stroke-width="2" fill="none"/><path d="M206 180h26l-6-10h-14z" fill="${p.accent}"/>`);
    // кресло
    add(`<rect x="262" y="226" width="64" height="58" rx="14" fill="${p.main}"/><rect x="256" y="270" width="76" height="18" rx="8" fill="${p.main}"/><path d="M294 288v34M272 330l22-8 22 8" stroke="${p.dark}" stroke-width="4" fill="none"/>`);
    add(`<ellipse cx="290" cy="330" rx="140" ry="18" fill="${p.rug}" fill-opacity=".7"/>`);
  }

  // растение — во всех «после»
  add(`<path d="M446 300l-10-48M446 300l12-56M446 300l-26-30M446 300l24-36" stroke="#4C6B4F" stroke-width="3" fill="none"/>`);
  for (const [x, y, r] of [[436, 250, -30], [458, 242, 25], [420, 268, -60], [470, 262, 50], [446, 232, 0]])
    add(`<ellipse cx="${x}" cy="${y}" rx="8" ry="16" fill="#5E8263" transform="rotate(${r} ${x} ${y})"/>`);
  add(`<path d="M428 298h36l-5 38h-26z" fill="${p.accent}"/>`);
  return `<svg viewBox="0 0 480 360" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">${s.join('')}</svg>`;
};
