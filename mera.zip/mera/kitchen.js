/* Рисунки кухонь: вид спереди, который меняется по ответам квиза, и схемы планировок */
(() => {
const shade = (hex, k) => {
  const n = parseInt(hex.slice(1), 16);
  const f = c => Math.max(0, Math.min(255, Math.round(c * k)));
  return '#' + [f(n >> 16), f(n >> 8 & 255), f(n & 255)].map(x => x.toString(16).padStart(2, '0')).join('');
};

window.kitchenSVG = function (o) {
  const p = Object.assign({length: 3.6, facade: '#E9E4DC', top: '#D8D2C8', appl: [], layout: 'line', wall: '#F2EDE6'}, o);
  const W = 600, H = 400;
  const n = Math.max(3, Math.min(12, Math.round(p.length / 0.6)));
  const mw = Math.min(84, 500 / n);
  const x0 = (W - mw * n) / 2;
  const has = k => p.appl.includes(k);
  const edge = shade(p.facade, .82), top2 = shade(p.top, .85);
  const s = [];
  s.push(`<rect width="${W}" height="${H}" fill="${p.wall}"/>`);
  s.push(`<rect y="362" width="${W}" height="38" fill="#D9CFC2"/>`);
  s.push(`<rect x="${x0}" y="150" width="${mw * n}" height="100" fill="#fff" fill-opacity=".55"/>`);
  for (let y = 162; y < 250; y += 18) s.push(`<line x1="${x0}" x2="${x0 + mw * n}" y1="${y}" y2="${y}" stroke="#000" stroke-opacity=".05"/>`);

  let start = 0;
  const fridge = has('fridge');
  if (fridge) {
    s.push(`<rect x="${x0}" y="40" width="${mw}" height="322" rx="3" fill="${p.facade}" stroke="${edge}"/>`);
    s.push(`<line x1="${x0}" x2="${x0 + mw}" y1="170" y2="170" stroke="${edge}"/>`);
    s.push(`<rect x="${x0 + mw - 12}" y="120" width="3" height="36" rx="1.5" fill="#6d665f"/><rect x="${x0 + mw - 12}" y="184" width="3" height="40" rx="1.5" fill="#6d665f"/>`);
    start = 1;
  }
  const cnt = n - start;
  const sinkI = start + Math.max(0, Math.floor(cnt * .28));
  let cookI = start + Math.min(cnt - 1, Math.floor(cnt * .72));
  if (cookI === sinkI) cookI = Math.min(n - 1, sinkI + 2);
  const dwI = sinkI + 1 < n && sinkI + 1 !== cookI ? sinkI + 1 : -1;

  // столешница
  const tx = x0 + start * mw, tw = (n - start) * mw;
  s.push(`<rect x="${tx - 4}" y="250" width="${tw + 8}" height="12" fill="${p.top}"/><rect x="${tx - 4}" y="259" width="${tw + 8}" height="3" fill="${top2}"/>`);
  // нижние модули
  for (let i = start; i < n; i++) {
    const x = x0 + i * mw;
    if (i === cookI && has('oven')) {
      s.push(`<rect x="${x + 1}" y="262" width="${mw - 2}" height="90" fill="#2C2B2A"/><rect x="${x + 7}" y="276" width="${mw - 14}" height="52" rx="3" fill="#44403C"/><rect x="${x + 7}" y="268" width="${mw - 14}" height="3" rx="1.5" fill="#8a8580"/>`);
    } else if (i === dwI && has('dw')) {
      s.push(`<rect x="${x + 1}" y="262" width="${mw - 2}" height="90" fill="${p.facade}" stroke="${edge}"/><rect x="${x + 8}" y="268" width="${mw - 16}" height="3" rx="1.5" fill="#6d665f"/><circle cx="${x + mw - 10}" cy="344" r="2.5" fill="#6FB38A"/>`);
    } else {
      s.push(`<rect x="${x + 1}" y="262" width="${mw - 2}" height="42" fill="${p.facade}" stroke="${edge}"/><rect x="${x + 1}" y="306" width="${mw - 2}" height="46" fill="${p.facade}" stroke="${edge}"/>`);
      s.push(`<rect x="${x + mw / 2 - 12}" y="270" width="24" height="3" rx="1.5" fill="#6d665f"/><rect x="${x + mw / 2 - 12}" y="314" width="24" height="3" rx="1.5" fill="#6d665f"/>`);
    }
  }
  s.push(`<rect x="${tx}" y="352" width="${tw}" height="10" fill="${shade(p.facade, .7)}"/>`);
  // мойка
  const sx = x0 + sinkI * mw;
  s.push(`<rect x="${sx + 8}" y="248" width="${mw - 16}" height="4" rx="2" fill="#9A958F"/><path d="M${sx + mw / 2} 248v-26q0-8 8-8h6" fill="none" stroke="#8C8781" stroke-width="3" stroke-linecap="round"/>`);
  // варочная
  const cx = x0 + cookI * mw;
  if (has('hob')) s.push(`<rect x="${cx + 6}" y="246" width="${mw - 12}" height="5" rx="1.5" fill="#1F1E1D"/>`);
  // верхние модули
  for (let i = start; i < n; i++) {
    const x = x0 + i * mw;
    if (i === cookI && has('hood')) {
      s.push(`<path d="M${x + mw / 2 - 9} 40h18v74h${mw / 2 - 1}l-6 22H${x + 7}l-6-22h${mw / 2 - 1}z" fill="#BDB8B1" stroke="#A29C95"/>`);
      continue;
    }
    s.push(`<rect x="${x + 1}" y="40" width="${mw - 2}" height="104" fill="${p.facade}" stroke="${edge}"/><rect x="${x + mw / 2 - 12}" y="134" width="24" height="3" rx="1.5" fill="#6d665f"/>`);
  }
  // посуда и растение для жизни
  s.push(`<rect x="${x0 + (start + (dwI > 0 ? 3 : 2)) * mw + 10}" y="232" width="12" height="18" rx="2" fill="#fff" stroke="#CFC8BF"/><path d="M${x0 + (start + (dwI > 0 ? 3 : 2)) * mw + 30} 250c0-14 6-20 8-20s8 6 8 20z" fill="#7C9A7E"/>`);
  if (p.layout !== 'line') {
    s.push(`<text x="${W - 16}" y="${H - 14}" text-anchor="end" font-family="Inter Tight, sans-serif" font-size="13" fill="#8C8580">вид на основную стену</text>`);
  }
  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Эскиз кухни">${s.join('')}</svg>`;
};

window.planSVG = function (layout, color = '#7A2E2A', bg = '#E7E2DB') {
  const shapes = {
    line: `<rect x="10" y="12" width="60" height="14" rx="2" fill="${color}"/>`,
    corner: `<rect x="10" y="12" width="60" height="14" rx="2" fill="${color}"/><rect x="10" y="12" width="14" height="50" rx="2" fill="${color}"/>`,
    u: `<rect x="10" y="12" width="60" height="14" rx="2" fill="${color}"/><rect x="10" y="12" width="14" height="50" rx="2" fill="${color}"/><rect x="56" y="12" width="14" height="50" rx="2" fill="${color}"/>`,
    island: `<rect x="10" y="12" width="60" height="14" rx="2" fill="${color}"/><rect x="24" y="44" width="32" height="16" rx="2" fill="${color}" fill-opacity=".7"/>`
  };
  return `<svg viewBox="0 0 80 70" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect x="4" y="6" width="72" height="60" rx="4" fill="none" stroke="${bg}" stroke-width="2" stroke-dasharray="3 3"/>${shapes[layout]}</svg>`;
};
})();
