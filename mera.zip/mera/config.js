/* Настройки отправки заявок.
 *
 * mode:
 *   'demo'   — ничего не отправляется, после квиза показывается, как заявка
 *              выглядела бы в Telegram и в Google Таблице. Для портфолио.
 *   'worker' — заявка уходит на ваш Cloudflare Worker (integrations/worker.js),
 *              а он уже пишет в Telegram и в таблицу. Токен бота скрыт. Рекомендуется.
 *   'direct' — прямо из браузера в Bot API и Apps Script. Только для проверки:
 *              токен бота виден любому, кто откроет код страницы.
 *
 * Подробная настройка — в README.md.
 */
window.MERA_CONFIG = {
  mode: 'demo',
  workerUrl: '',                  // https://mera-leads.<ваш-аккаунт>.workers.dev
  telegram: {botToken: '', chatId: ''},   // только для mode: 'direct'
  sheetsUrl: ''                   // https://script.google.com/macros/s/.../exec — для mode: 'direct'
};
