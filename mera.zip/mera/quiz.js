/* Мера — логика квиза, расчёт и отправка заявки */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const nf = new Intl.NumberFormat('ru-RU');
const rub = n => nf.format(Math.round(n)) + ' ₽';
const thous = n => nf.format(Math.round(n / 1000)) + ' тыс.';
const m = v => String(v).replace('.', ',');
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));

/* ---------- данные ---------- */
const LAYOUTS = {
  line:   {name: 'Прямая', k: 1, extra: 0},
  corner: {name: 'Угловая', k: 1.06, extra: 18000},
  u:      {name: 'П-образная', k: 1.12, extra: 36000},
  island: {name: 'С островом', k: 1, extra: 95000}
};
const FACADES = [
  {id: 'ldsp', name: 'ЛДСП', note: 'практично, 40+ декоров', rate: 36000},
  {id: 'agt', name: 'Пластик AGT', note: 'мат или глянец, не боится влаги', rate: 49000},
  {id: 'enamel', name: 'МДФ в эмали', note: 'любой цвет, бархатистый мат', rate: 64000},
  {id: 'veneer', name: 'Шпон дуба', note: 'натуральное дерево под маслом', rate: 82000}
];
const F_COLORS = [
  {id: 'milk', name: 'Молочный', c: '#EEE8DE'}, {id: 'sage', name: 'Шалфей', c: '#9DAA93'},
  {id: 'graphite', name: 'Графит', c: '#4A4B4D'}, {id: 'navy', name: 'Глубокий синий', c: '#2F4A66'},
  {id: 'terra', name: 'Терракота', c: '#B8735A'}, {id: 'oak', name: 'Дуб натуральный', c: '#C49A6C'}
];
const TOPS = [
  {id: 'lam', name: 'ДСП с пластиком', note: 'толщина 38 мм, бюджетно', rate: 5000},
  {id: 'oak', name: 'Массив дуба', note: 'тёплая, требует масла раз в год', rate: 16000},
  {id: 'quartz', name: 'Кварцевый агломерат', note: 'не царапается и не впитывает', rate: 29000}
];
const T_COLORS = [
  {id: 'marble', name: 'Белый мрамор', c: '#ECEAE6'}, {id: 'concrete', name: 'Бетон', c: '#B9B6B0'},
  {id: 'black', name: 'Чёрный камень', c: '#2B2A29'}, {id: 'wood', name: 'Тёплое дерево', c: '#B98B5E'}
];
const APPL = [
  {id: 'oven', name: 'Духовой шкаф', price: 45000}, {id: 'hob', name: 'Варочная панель', price: 32000},
  {id: 'dw', name: 'Посудомоечная машина', price: 46000}, {id: 'hood', name: 'Вытяжка', price: 24000},
  {id: 'fridge', name: 'Встраиваемый холодильник', price: 92000}
];
const WHEN = ['В течение месяца', 'Через 1–3 месяца', 'Через 3–6 месяцев', 'Пока присматриваюсь'];
const GIFTS = [
  {id: 'discount', name: 'Скидка 10% на корпус и фасады', note: 'самый выгодный для больших кухонь'},
  {id: 'sink', name: 'Мойка и смеситель в подарок', note: 'кварцевая мойка Florentina и смеситель, 18 000 ₽'},
  {id: 'mount', name: 'Бесплатная доставка и сборка', note: 'обычно 6% от стоимости мебели'}
];
const STEPS = ['layout', 'length', 'facade', 'top', 'appl', 'when', 'gift', 'contact'];

const S = {layout: null, length: 3.6, facade: null, fColor: 'milk', top: null, tColor: 'marble', appl: [], when: null, gift: null};

/* ---------- отрисовка опций ---------- */
$$('.plan-ico').forEach(el => el.innerHTML = planSVG(el.dataset.plan));
const optRow = (type, name, value, title, note, right = '') =>
  `<label class="opt opt--row"><input type="${type}" name="${name}" value="${value}"><span class="tick"></span><span class="txt"><b>${title}</b>${note ? `<br><small>${note}</small>` : ''}</span>${right ? `<em>${right}</em>` : ''}</label>`;
$('#facadeMat').innerHTML = FACADES.map(f => optRow('radio', 'facade', f.id, f.name, f.note, `${thous(f.rate)}/м`)).join('');
$('#topMat').innerHTML = TOPS.map(t => optRow('radio', 'top', t.id, t.name, t.note, `${thous(t.rate)}/м`)).join('');
$('#applList').innerHTML = APPL.map(a => optRow('checkbox', 'appl', a.id, a.name, '', `от ${thous(a.price)}`)).join('');
$('#whenList').innerHTML = WHEN.map((w, i) => optRow('radio', 'when', i, w, '')).join('');
$('#giftList').innerHTML = GIFTS.map(g => optRow('radio', 'gift', g.id, g.name, g.note)).join('');
const swatches = (list, name, current) => list.map(c => `<label class="sw" title="${c.name}"><input type="radio" name="${name}" value="${c.id}" ${c.id === current ? 'checked' : ''} aria-label="${c.name}"><span style="background:${c.c}"></span></label>`).join('');
$('#facadeColors').innerHTML = swatches(F_COLORS, 'fColor', S.fColor);
$('#topColors').innerHTML = swatches(T_COLORS, 'tColor', S.tColor);

/* ---------- расчёт ---------- */
function calc() {
  const L = LAYOUTS[S.layout || 'line'];
  const f = FACADES.find(x => x.id === S.facade) || FACADES[0];
  const t = TOPS.find(x => x.id === S.top) || TOPS[0];
  const furniture = S.length * f.rate * L.k + L.extra;
  const topLen = S.length + (S.layout === 'island' ? 1.8 : 0);
  const top = topLen * t.rate;
  const appl = S.appl.reduce((s, id) => s + APPL.find(a => a.id === id).price, 0);
  const mount = Math.max(15000, furniture * .06);
  const rows = [
    ['Корпус и фасады, ' + f.name, furniture],
    [`Столешница, ${m(topLen.toFixed(1))} м`, top],
    ...(appl ? [[`Техника, ${S.appl.length} шт.`, appl]] : []),
    ['Доставка и сборка', mount]
  ];
  let gift = 0, giftLabel = '';
  if (S.gift === 'discount') { gift = furniture * .1; giftLabel = 'Скидка 10% на мебель'; }
  if (S.gift === 'sink') { gift = 18000; giftLabel = 'Мойка и смеситель'; rows.splice(2, 0, ['Мойка и смеситель', 18000]); }
  if (S.gift === 'mount') { gift = mount; giftLabel = 'Доставка и сборка'; }
  const total = rows.reduce((s, r) => s + r[1], 0) - gift;
  const r5 = v => Math.round(v / 5000) * 5000;
  return {rows, gift, giftLabel, total, lo: r5(total * .94), hi: r5(total * 1.08)};
}

/* ---------- превью ---------- */
const heroKitchen = {length: 4.2, facade: '#9DAA93', top: '#ECEAE6', appl: ['oven', 'hob', 'hood', 'dw']};
$('#heroArt').innerHTML = kitchenSVG(heroKitchen);
function renderPreview() {
  const fc = F_COLORS.find(c => c.id === S.fColor).c, tc = T_COLORS.find(c => c.id === S.tColor).c;
  const pv = $('#preview');
  pv.innerHTML = kitchenSVG({length: S.length, facade: fc, top: tc, appl: S.appl, layout: S.layout || 'line'}) + `<div class="plan-mini">${planSVG(S.layout || 'line')}</div>`;
  $('#sideLen').textContent = m(S.length) + ' м';
  $('#facadeName').textContent = F_COLORS.find(c => c.id === S.fColor).name;
  $('#topName').textContent = T_COLORS.find(c => c.id === S.tColor).name;
  const val = (v, empty = 'не выбрано') => v ? `<b>${v}</b>` : `<b class="empty">${empty}</b>`;
  const f = FACADES.find(x => x.id === S.facade), t = TOPS.find(x => x.id === S.top);
  $('#specs').innerHTML = [
    ['Планировка', val(S.layout && LAYOUTS[S.layout].name)],
    ['Длина', val(step > 1 ? m(S.length) + ' м' : '')],
    ['Фасады', val(f && `${f.name}, ${F_COLORS.find(c => c.id === S.fColor).name.toLowerCase()}`)],
    ['Столешница', val(t && `${t.name}, ${T_COLORS.find(c => c.id === S.tColor).name.toLowerCase()}`)],
    ['Техника', val(step > 4 ? (S.appl.length ? S.appl.length + ' шт.' : 'своя') : '')]
  ].map(([a, b]) => `<li><span>${a}</span>${b}</li>`).join('');
}

/* ---------- навигация ---------- */
let step = 0;
const form = $('#qForm'), next = $('#qNext'), back = $('#qBack');
const ready = () => {
  const k = STEPS[step];
  if (k === 'layout') return !!S.layout;
  if (k === 'facade') return !!S.facade;
  if (k === 'top') return !!S.top;
  if (k === 'when') return S.when !== null;
  if (k === 'gift') return !!S.gift;
  return true;
};
function show() {
  $$('.q-step', form).forEach(el => el.classList.toggle('on', el.dataset.step === STEPS[step]));
  const last = step === STEPS.length - 1;
  $('#qCount').innerHTML = last ? '<b>Последний шаг</b>' : `Вопрос <b>${step + 1}</b> из ${STEPS.length - 1}`;
  $('#qLeft').textContent = last ? '' : step < 3 ? 'около 2 минут' : 'меньше минуты';
  $('#qBar').style.width = ((step + (last ? 1 : 0)) / (STEPS.length - 1) * 100) + '%';
  back.hidden = step === 0;
  next.textContent = last ? 'Получить расчёт' : 'Дальше';
  next.disabled = !ready();
  renderPreview();
}
const go = d => {
  step = Math.max(0, Math.min(STEPS.length - 1, step + d)); show();
  const first = $(`.q-step[data-step="${STEPS[step]}"] input`, form);
  if (d > 0 && first && innerWidth > 980) first.focus({preventScroll: true});
  if (innerWidth <= 980) $('#quiz').scrollIntoView({behavior: 'smooth', block: 'start'});
};
back.addEventListener('click', () => go(-1));

let autoTimer;
form.addEventListener('change', e => {
  const t = e.target;
  if (t.name === 'layout') S.layout = t.value;
  if (t.name === 'facade') S.facade = t.value;
  if (t.name === 'fColor') S.fColor = t.value;
  if (t.name === 'top') S.top = t.value;
  if (t.name === 'tColor') S.tColor = t.value;
  if (t.name === 'appl') S.appl = $$('input[name=appl]:checked', form).map(i => i.value);
  if (t.name === 'when') S.when = +t.value;
  if (t.name === 'gift') S.gift = t.value;
  if (t.name === 'layout') {
    $('#lenHint').textContent = {line: 'Измерьте стену, вдоль которой встанет кухня.', corner: 'Сложите длину обеих сторон угла.', u: 'Сложите длину всех трёх сторон.', island: 'Длина основной стены — остров посчитаем отдельно.'}[S.layout];
  }
  next.disabled = !ready();
  renderPreview();
  // одиночный выбор — сразу к следующему вопросу
  if (['layout', 'when', 'gift'].includes(t.name)) { clearTimeout(autoTimer); autoTimer = setTimeout(() => go(1), 280); }
});
const len = $('#len');
const paintLen = () => { len.style.setProperty('--p', ((len.value - len.min) / (len.max - len.min) * 100) + '%'); $('#lenOut').textContent = m(len.value); };
len.addEventListener('input', () => { S.length = +len.value; paintLen(); renderPreview(); });
paintLen();

/* ---------- контакты ---------- */
const phone = $('#cPhone'), nameI = $('#cName');
phone.addEventListener('input', () => {
  let d = phone.value.replace(/\D/g, '');
  if (!d) { phone.value = ''; return; }
  if (d[0] === '8') d = '7' + d.slice(1);
  if (d[0] !== '7') d = '7' + d;
  d = d.slice(0, 11);
  const p = [d.slice(1, 4), d.slice(4, 7), d.slice(7, 9), d.slice(9, 11)];
  phone.value = '+7' + (p[0] ? ' ' + p[0] : '') + (p[1] ? ' ' + p[1] : '') + (p[2] ? '-' + p[2] : '') + (p[3] ? '-' + p[3] : '');
});
const err = (k, msg) => { const f = $(`[data-f="${k}"]`, form); f.classList.toggle('err', !!msg); $('.msg', f).textContent = msg || ''; return !msg; };
nameI.addEventListener('input', () => err('name', ''));
phone.addEventListener('input', () => err('phone', ''));

form.addEventListener('submit', async e => {
  e.preventDefault();
  if (step < STEPS.length - 1) { if (ready()) go(1); return; }
  const a = err('name', nameI.value.trim() ? '' : 'Напишите, как к вам обращаться');
  const b = err('phone', phone.value.replace(/\D/g, '').length === 11 ? '' : 'Нужен номер целиком: +7 и 10 цифр');
  if (!a || !b) { $('.f.err input', form).focus(); return; }
  next.disabled = true; next.textContent = 'Считаем…';
  const lead = buildLead();
  const status = await send(lead);
  showResult(lead, status);
});

/* ---------- заявка ---------- */
function buildLead() {
  const c = calc();
  const f = FACADES.find(x => x.id === S.facade), t = TOPS.find(x => x.id === S.top);
  const q = new URLSearchParams(location.search);
  return {
    date: new Date().toLocaleString('ru-RU', {timeZone: 'Europe/Moscow', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'}),
    name: nameI.value.trim(), phone: phone.value, via: $('input[name=via]:checked', form).value,
    layout: LAYOUTS[S.layout].name, length: m(S.length) + ' м',
    facade: `${f.name}, ${F_COLORS.find(x => x.id === S.fColor).name}`,
    top: `${t.name}, ${T_COLORS.find(x => x.id === S.tColor).name}`,
    appliances: S.appl.length ? S.appl.map(id => APPL.find(a => a.id === id).name).join(', ') : 'своя / не нужна',
    when: WHEN[S.when], gift: GIFTS.find(g => g.id === S.gift).name,
    priceFrom: c.lo, priceTo: c.hi,
    source: q.get('utm_source') ? `${q.get('utm_source')} / ${q.get('utm_campaign') || '—'}` : 'прямой заход',
    calc: c
  };
}
function tgText(l) {
  return `<b>Новая заявка с квиза</b>\n\n` +
    `<b>${esc(l.name)}</b>, ${esc(l.phone)}\nСвязаться: ${esc(l.via)}\n\n` +
    `Кухня: ${esc(l.layout.toLowerCase())}, ${esc(l.length)}\nФасады: ${esc(l.facade)}\nСтолешница: ${esc(l.top)}\nТехника: ${esc(l.appliances)}\n` +
    `Сроки: ${esc(l.when)}\nПодарок: ${esc(l.gift)}\n\n` +
    `<b>Расчёт: ${nf.format(l.priceFrom)}–${nf.format(l.priceTo)} ₽</b>\nИсточник: ${esc(l.source)}`;
}
async function send(lead) {
  const cfg = window.MERA_CONFIG || {mode: 'demo'};
  const payload = {...lead}; delete payload.calc;
  try {
    if (cfg.mode === 'worker' && cfg.workerUrl) {
      const r = await fetch(cfg.workerUrl, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
      if (!r.ok) throw new Error(r.status);
      return 'sent';
    }
    if (cfg.mode === 'direct') {
      const jobs = [];
      if (cfg.telegram.botToken && cfg.telegram.chatId) {
        jobs.push(fetch(`https://api.telegram.org/bot${cfg.telegram.botToken}/sendMessage`, {
          method: 'POST', headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({chat_id: cfg.telegram.chatId, text: tgText(lead), parse_mode: 'HTML'})
        }).then(r => { if (!r.ok) throw new Error('tg ' + r.status); }));
      }
      // Apps Script не отдаёт CORS-заголовки, поэтому отправляем «вслепую»
      if (cfg.sheetsUrl) jobs.push(fetch(cfg.sheetsUrl, {method: 'POST', mode: 'no-cors', body: JSON.stringify(payload)}));
      await Promise.all(jobs);
      return jobs.length ? 'sent' : 'demo';
    }
  } catch (e) {
    console.warn('Не удалось отправить заявку', e);
    return 'failed';
  }
  return 'demo';
}

function showResult(l, status) {
  const c = l.calc;
  $$('.q-step', form).forEach(el => el.classList.remove('on'));
  $('#qNav').hidden = true;
  $('.quiz').classList.add('done');
  $('#qCount').innerHTML = '<b>Расчёт готов</b>';
  $('#qLeft').textContent = '';
  $('#qBar').style.width = '100%';
  const note = {
    sent: `<p class="sent-note"><i></i>Расчёт и подборку проектов пришлём в ${esc(l.via === 'Звонок' ? 'течение 15 минут звонком' : l.via)} на ${esc(l.phone)}.</p>`,
    demo: `<p class="sent-note"><i></i>Демо-режим: заявка никуда не ушла, но можно посмотреть, как её увидел бы владелец.</p>`,
    failed: `<p class="sent-note warn"><i></i>Не получилось отправить заявку автоматически. Позвоните нам: <a href="tel:+78432075519" style="font-weight:600">+7 843 207-55-19</a> — назовите сумму расчёта.</p>`
  }[status];
  $('#result').innerHTML = `
    <span class="done-ico"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span>
    <h2>${esc(l.name)}, ваша кухня обойдётся</h2>
    <div class="price-box"><span>Предварительно, с учётом подарка</span><b>${nf.format(c.lo)} – ${nf.format(c.hi)}&nbsp;₽</b><small>Цену зафиксируем в договоре после замера</small></div>
    <ul class="breakdown">${c.rows.map(([a, v]) => `<li><span>${a}</span><b>${rub(v)}</b></li>`).join('')}
      <li class="gift"><span>Подарок: ${c.giftLabel.toLowerCase()}</span><b>−${rub(c.gift)}</b></li></ul>
    ${note}
    <div style="display:flex;gap:10px;flex-wrap:wrap">${status === 'demo' ? '<button type="button" class="btn btn--main" id="openDemo">Как выглядит заявка</button>' : ''}<button type="button" class="btn btn--ghost" id="again">Пересчитать</button></div>`;
  $('#result').classList.add('on');
  $('#again').addEventListener('click', () => { $('#result').classList.remove('on'); $('.quiz').classList.remove('done'); $('#qNav').hidden = false; step = 0; show(); });
  const od = $('#openDemo');
  if (od) od.addEventListener('click', () => openDemo(l));
  if (status === 'demo') openDemo(l);
  if (innerWidth <= 980) $('#quiz').scrollIntoView({behavior: 'smooth'});
}

/* ---------- демо: как заявка выглядит у владельца ---------- */
const demo = $('#demo');
const SAMPLE = [
  ['27.09.2026, 18:42', 'Ильдар', '+7 917 284-11-06', 'Угловая, 4,2 м', 'МДФ в эмали, Шалфей', '385 000–440 000', 'yandex / kuhni_kzn'],
  ['28.09.2026, 11:15', 'Светлана', '+7 960 051-72-38', 'Прямая, 3 м', 'ЛДСП, Молочный', '165 000–190 000', 'прямой заход']
];
function openDemo(l) {
  const time = new Date().toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'});
  $('#tgMsg').innerHTML = `<div class="from">Мера · Заявки</div>${tgText(l)}<time>${time}</time>`;
  const head = ['Дата', 'Имя', 'Телефон', 'Кухня', 'Фасады', 'Расчёт, ₽', 'Источник'];
  const cur = [l.date, l.name, l.phone, `${l.layout}, ${l.length}`, l.facade, `${nf.format(l.priceFrom)}–${nf.format(l.priceTo)}`, l.source];
  const row = (cells, i, cls = '') => `<tr class="${cls}"><td class="rn">${i}</td>${cells.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`;
  $('#sheet').innerHTML = `<table><tr><th></th>${'ABCDEFG'.split('').map(x => `<th>${x}</th>`).join('')}</tr>${row(head, 1)}${SAMPLE.map((r, i) => row(r, i + 2)).join('')}${row(cur, 4, 'new')}</table>`;
  demo.showModal();
}
$('#demoX').addEventListener('click', () => demo.close());
demo.addEventListener('click', e => { if (e.target === demo) demo.close(); });

/* ---------- примеры работ ---------- */
const WORKS = [
  {t: 'ЖК «Светлая долина»', d: 'Угловая 3,8 м, эмаль шалфей, кварц', p: '312 000 ₽', k: {length: 3.8, facade: '#9DAA93', top: '#ECEAE6', appl: ['oven', 'hob', 'hood']}},
  {t: 'Дом в Высокой Горе', d: 'С островом, шпон дуба, чёрный камень', p: '684 000 ₽', k: {length: 5, facade: '#C49A6C', top: '#2B2A29', appl: ['oven', 'hob', 'dw', 'hood', 'fridge']}},
  {t: 'Квартира на Вахитова', d: 'Прямая 2,8 м, AGT графит, бетон', p: '198 000 ₽', k: {length: 2.8, facade: '#4A4B4D', top: '#B9B6B0', appl: ['hob', 'hood']}}
];
$('#works').innerHTML = WORKS.map(w => `<article class="work">${kitchenSVG(w.k)}<div><b>${w.t}</b><span>${w.d} — ${w.p}</span></div></article>`).join('');

$('#startBtn').addEventListener('click', () => setTimeout(() => $('input[name=layout]', form).focus({preventScroll: true}), 500));
show();
})();
