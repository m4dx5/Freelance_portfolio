/**
 * Cloudflare Worker: принимает заявку с квиза и пересылает её
 * в Telegram и в Google Таблицу. Токен бота хранится в секретах воркера
 * и не виден посетителям сайта.
 *
 * Переменные окружения (Settings → Variables):
 *   BOT_TOKEN       — токен бота от @BotFather            (secret)
 *   CHAT_ID         — id чата или группы менеджеров
 *   SHEETS_URL      — адрес веб-приложения Apps Script      (необязательно)
 *   ALLOWED_ORIGIN  — адрес сайта, например https://mera-kzn.ru
 */
export default {
  async fetch(request, env) {
    const cors = {
      'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    };
    if (request.method === 'OPTIONS') return new Response(null, {headers: cors});
    if (request.method !== 'POST') return new Response('Method not allowed', {status: 405, headers: cors});

    const origin = request.headers.get('Origin');
    if (env.ALLOWED_ORIGIN && origin !== env.ALLOWED_ORIGIN) return new Response('Forbidden', {status: 403, headers: cors});

    let lead;
    try {
      const raw = await request.text();
      if (raw.length > 5000) throw new Error('too large');
      lead = JSON.parse(raw);
    } catch {
      return json({ok: false, error: 'bad_request'}, 400, cors);
    }

    const phoneDigits = String(lead.phone || '').replace(/\D/g, '');
    if (!lead.name || phoneDigits.length !== 11) return json({ok: false, error: 'validation'}, 422, cors);

    const esc = s => String(s ?? '').slice(0, 200).replace(/[&<>]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;'}[c]));
    const nf = n => Number(n || 0).toLocaleString('ru-RU');
    const text =
      `<b>Новая заявка с квиза</b>\n\n` +
      `<b>${esc(lead.name)}</b>, ${esc(lead.phone)}\nСвязаться: ${esc(lead.via)}\n\n` +
      `Кухня: ${esc(lead.layout)}, ${esc(lead.length)}\nФасады: ${esc(lead.facade)}\nСтолешница: ${esc(lead.top)}\n` +
      `Техника: ${esc(lead.appliances)}\nСроки: ${esc(lead.when)}\nПодарок: ${esc(lead.gift)}\n\n` +
      `<b>Расчёт: ${nf(lead.priceFrom)}–${nf(lead.priceTo)} ₽</b>\nИсточник: ${esc(lead.source)}`;

    const jobs = [
      fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          chat_id: env.CHAT_ID, text, parse_mode: 'HTML',
          reply_markup: {inline_keyboard: [[{text: 'Написать в Telegram', url: `https://t.me/+${phoneDigits}`}]]}
        })
      })
    ];
    if (env.SHEETS_URL) {
      jobs.push(fetch(env.SHEETS_URL, {method: 'POST', headers: {'Content-Type': 'text/plain'}, body: JSON.stringify(lead)}));
    }
    const results = await Promise.allSettled(jobs);
    const tgOk = results[0].status === 'fulfilled' && results[0].value.ok;
    return json({ok: tgOk}, tgOk ? 200 : 502, cors);
  }
};

function json(data, status, headers) {
  return new Response(JSON.stringify(data), {status, headers: {...headers, 'Content-Type': 'application/json'}});
}
