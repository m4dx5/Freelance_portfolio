/**
 * Google Apps Script: записывает заявки с квиза в таблицу.
 *
 * 1. Создайте Google Таблицу, откройте «Расширения → Apps Script».
 * 2. Вставьте этот код, сохраните.
 * 3. «Начать развёртывание → Новое развёртывание → Веб-приложение»,
 *    «Выполнять от имени: меня», «Доступ: все». Скопируйте URL — он заканчивается на /exec.
 * 4. Вставьте URL в config.js (sheetsUrl) или в переменную SHEETS_URL воркера.
 */
const SHEET_NAME = 'Заявки';
const HEADERS = ['Дата', 'Имя', 'Телефон', 'Связаться', 'Планировка', 'Длина', 'Фасады', 'Столешница',
                 'Техника', 'Сроки', 'Подарок', 'Цена от', 'Цена до', 'Источник', 'Статус'];

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const lead = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(HEADERS);
      sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold').setBackground('#F1F3F4');
      sheet.setFrozenRows(1);
    }
    const clean = v => String(v == null ? '' : v).slice(0, 200).replace(/^[=+\-@]/, "'$&"); // защита от формул
    sheet.appendRow([
      new Date(), clean(lead.name), clean(lead.phone), clean(lead.via), clean(lead.layout), clean(lead.length),
      clean(lead.facade), clean(lead.top), clean(lead.appliances), clean(lead.when), clean(lead.gift),
      Number(lead.priceFrom) || '', Number(lead.priceTo) || '', clean(lead.source), 'Новая'
    ]);
    return ContentService.createTextOutput(JSON.stringify({ok: true})).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ok: false, error: String(err)})).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}
